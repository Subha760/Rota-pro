"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ArrowLeftRight } from "lucide-react";
import type { SwapPayload } from "@/types/rota";
import { decodeSwap } from "@/lib/swap";
import { monthName } from "@/lib/utils";
import { lookupShift, shiftByType } from "@/lib/shift-definitions";

export default function SwapPage({ params }: { params: { hash: string } }) {
  const [payload, setPayload] = useState<SwapPayload | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fromHash = typeof window !== "undefined" ? window.location.hash.replace(/^#/, "") : "";
    const decoded = fromHash ? decodeSwap(fromHash) : null;
    if (decoded) {
      setPayload(decoded);
      return;
    }
    fetch(`/api/swap?hash=${encodeURIComponent(params.hash)}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setPayload(j.payload);
        else setError(j.error || "Not found");
      })
      .catch(() => setError("Could not load swap payload"));
  }, [params.hash]);

  return (
    <div className="mx-auto min-h-screen max-w-3xl px-4 py-10">
      <Link href="/" className="inline-flex items-center gap-2 text-sm text-teal-300">
        <ArrowLeft className="h-4 w-4" />
        Back to RotaPro
      </Link>
      <h1 className="mt-6 font-display text-3xl text-white flex items-center gap-2">
        <ArrowLeftRight className="h-7 w-7 text-teal-300" />
        Shared roster
      </h1>
      {error && <p className="mt-4 text-rose-300">{error}</p>}
      {payload && (
        <div className="mt-6 rounded-3xl border border-white/10 bg-navy-900/70 p-5">
          <p className="text-slate-300">
            {payload.profile.name} · {payload.profile.ward} · {monthName(payload.month)} {payload.year}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Open RotaPro, load your month, then paste this URL into the swap assistant to find conflict-free
            slots.
          </p>
          <div className="mt-5 grid grid-cols-7 gap-1.5">
            {payload.schedule.map((c) => {
              const def = lookupShift(c.raw_code) ?? shiftByType(c.normalized_type);
              return (
                <div
                  key={c.day}
                  className="rounded-xl p-2 text-center text-[11px]"
                  style={{ background: `${def.color}22`, color: def.color }}
                >
                  <div className="text-slate-400">{c.day}</div>
                  <div className="font-semibold">{c.raw_code}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
