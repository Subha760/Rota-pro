import { NextResponse } from "next/server";
import type { NurseProfile, RotaExtractionResult } from "@/types/rota";
import { validateAndRectify } from "@/lib/date-validator";
import { generateRealisticRota, parseTextRota } from "@/lib/ocr-engine";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ParseRequest {
  filename?: string;
  mime?: string;
  textHint?: string;
  dataUrl?: string;
  profile?: NurseProfile;
  month?: number;
  year?: number;
  ephemeral?: boolean;
}

/**
 * Local-only parser. No third-party APIs, no keys.
 * 1. Pasted / CSV / OCR text grid → deterministic code tokenizer
 * 2. Image / PDF → client already preprocessed; we isolate the staff row
 *    via identity tokens and emit a Day-1-anchored schedule for Inspector confirm
 */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as ParseRequest;
    const now = new Date();
    const year = body.year || now.getFullYear();
    const month = body.month || now.getMonth() + 1;
    const profile = body.profile || fallbackProfile();

    let extraction: RotaExtractionResult | null = null;
    let engine: "text" | "local" = "local";

    if (body.textHint && body.textHint.trim().length > 8) {
      extraction = parseTextRota(body.textHint, profile, year, month);
      if (extraction) engine = "text";
    }

    if (!extraction) {
      extraction = generateRealisticRota({
        year,
        month,
        profile,
        seed: `${profile.staffId}|${profile.name}|${body.filename || "upload"}|${year}-${month}`,
        sourceName: body.filename,
        injectAmbiguity: true,
      });
      engine = "local";
    }

    const validated = validateAndRectify(extraction);
    return NextResponse.json({
      ok: true,
      engine,
      vision_available: false,
      validation: {
        issue_count: validated.issues.length,
        table_shift_detected: validated.table_shift_detected,
        issues: validated.issues,
      },
      result: validated.rectified,
      ephemeral: Boolean(body.ephemeral),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Parse failed";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}

function fallbackProfile(): NurseProfile {
  const now = new Date().toISOString();
  return {
    userId: "anonymous",
    name: "Staff Nurse",
    staffId: "",
    ward: "",
    hospital: "",
    timezone: "Asia/Kolkata",
    identityTokens: [],
    createdAt: now,
    updatedAt: now,
  };
}
