import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { nanoid } from "nanoid";
import type { SwapPayload } from "@/types/rota";

const DIR = path.join(process.cwd(), "data", "swaps");

async function ensure() {
  await fs.mkdir(DIR, { recursive: true });
}

export async function POST(req: Request) {
  const payload = (await req.json()) as SwapPayload;
  await ensure();
  const hash = payload.hash || nanoid(16);
  const record = { ...payload, hash, createdAt: new Date().toISOString() };
  await fs.writeFile(path.join(DIR, `${hash}.json`), JSON.stringify(record), "utf8");
  return NextResponse.json({ ok: true, hash });
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const hash = url.searchParams.get("hash");
  if (!hash) return NextResponse.json({ ok: false, error: "Missing hash" }, { status: 400 });
  try {
    const raw = await fs.readFile(path.join(DIR, `${hash.replace(/[^a-zA-Z0-9_-]/g, "")}.json`), "utf8");
    return NextResponse.json({ ok: true, payload: JSON.parse(raw) });
  } catch {
    return NextResponse.json({ ok: false, error: "Swap not found" }, { status: 404 });
  }
}
