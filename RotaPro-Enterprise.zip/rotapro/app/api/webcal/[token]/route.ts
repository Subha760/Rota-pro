import { NextResponse } from "next/server";
import { getFeed, putFeed } from "@/lib/feed-store";
import { generateIcs } from "@/lib/ics-generator";
import type { FeedRecord, NurseProfile, PrivacySettings, RotaExtractionResult } from "@/types/rota";
import { DEFAULT_PRIVACY } from "@/lib/storage";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(
  _req: Request,
  { params }: { params: { token: string } }
) {
  const feed = await getFeed(params.token);
  if (!feed) {
    return new NextResponse("RotaPro feed not found. Upload a rota to activate this WebCal token.", {
      status: 404,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }
  return new NextResponse(feed.ics, {
    status: 200,
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `inline; filename="rotapro-${params.token.slice(0, 8)}.ics"`,
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "X-RotaPro-Sequence": String(feed.sequence),
    },
  });
}

export async function PUT(
  req: Request,
  { params }: { params: { token: string } }
) {
  try {
    const body = (await req.json()) as {
      extraction: RotaExtractionResult;
      profile: NurseProfile;
      sequence: number;
      privacy?: PrivacySettings;
    };
    const ics = generateIcs({
      extraction: body.extraction,
      profile: body.profile,
      sequence: body.sequence,
      privacy: body.privacy ?? DEFAULT_PRIVACY,
    });
    const record: FeedRecord = {
      token: params.token,
      userId: body.profile.userId,
      ics,
      extraction: {
        ...body.extraction,
        metadata: {
          ...body.extraction.metadata,
          staff_name: body.profile.name,
          staff_id: body.profile.staffId,
        },
      },
      sequence: body.sequence,
      updatedAt: new Date().toISOString(),
    };
    await putFeed(record);
    return NextResponse.json({ ok: true, sequence: body.sequence, bytes: ics.length });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Feed update failed";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
