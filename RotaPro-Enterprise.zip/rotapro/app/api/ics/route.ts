import { NextResponse } from "next/server";
import { generateIcs, icsFilename } from "@/lib/ics-generator";
import { DEFAULT_PRIVACY } from "@/lib/storage";
import type { NurseProfile, PrivacySettings, RotaExtractionResult } from "@/types/rota";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const body = (await req.json()) as {
    extraction: RotaExtractionResult;
    profile: NurseProfile;
    sequence: number;
    privacy?: PrivacySettings;
  };
  const ics = generateIcs({
    extraction: body.extraction,
    profile: body.profile,
    sequence: body.sequence,
    privacy: body.privacy ?? DEFAULT_PRIVACY,
  });
  return new NextResponse(ics, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="${icsFilename(body.extraction)}"`,
    },
  });
}
