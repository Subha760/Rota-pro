import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { RotaProvider } from "@/context/RotaContext";
import { PwaRegister } from "@/components/PwaRegister";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export const metadata: Metadata = {
  title: "RotaPro Enterprise · Rota2Cal",
  description:
    "Convert hospital duty rotas into verified RFC 5545 calendars, live WebCal feeds, and peer-to-peer shift swaps — with zero date misalignment.",
  applicationName: "RotaPro Enterprise",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "RotaPro",
  },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#070b12",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <RotaProvider>
          {children}
          <PwaRegister />
        </RotaProvider>
      </body>
    </html>
  );
}
