import type {
  NurseProfile,
  PrivacySettings,
  RotaExtractionResult,
  ScheduleCell,
} from "@/types/rota";
import { LEAVE_TYPES, lookupShift, shiftByType } from "@/lib/shift-definitions";
import { formatHours, hoursBetween, monthName, pad2 } from "@/lib/utils";

const CRLF = "\r\n";
const PRODID = "-//RotaPro Enterprise//Rota2Cal 1.0//EN";

function fold(line: string): string {
  const bytes: number[] = [];
  for (const ch of line) {
    const encoded = unescape(encodeURIComponent(ch));
    for (let i = 0; i < encoded.length; i++) bytes.push(encoded.charCodeAt(i));
  }
  if (bytes.length <= 75) return line;
  let out = "";
  let start = 0;
  let charIndex = 0;
  let budget = 75;
  const chars = [...line];
  while (charIndex < chars.length) {
    const ch = chars[charIndex];
    const size = unescape(encodeURIComponent(ch)).length;
    if (size > budget) {
      out += (out ? `${CRLF} ` : "") + chars.slice(start, charIndex).join("");
      start = charIndex;
      budget = 74;
    }
    budget -= size;
    charIndex++;
  }
  out += (out ? `${CRLF} ` : "") + chars.slice(start).join("");
  return out;
}

function escapeText(value: string): string {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/\n/g, "\\n")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,");
}

function utcStamp(d = new Date()): string {
  return (
    d.getUTCFullYear().toString() +
    pad2(d.getUTCMonth() + 1) +
    pad2(d.getUTCDate()) +
    "T" +
    pad2(d.getUTCHours()) +
    pad2(d.getUTCMinutes()) +
    pad2(d.getUTCSeconds()) +
    "Z"
  );
}

function localStamp(year: number, month: number, day: number, hhmm: string): string {
  const [h, m] = hhmm.split(":").map((v) => parseInt(v, 10));
  return `${year}${pad2(month)}${pad2(day)}T${pad2(h || 0)}${pad2(m || 0)}00`;
}

function dateValue(year: number, month: number, day: number): string {
  return `${year}${pad2(month)}${pad2(day)}`;
}

function addDays(year: number, month: number, day: number, delta: number) {
  const d = new Date(year, month - 1, day + delta);
  return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
}

export function eventUid(userId: string, year: number, month: number, day: number, suffix = ""): string {
  return `rota-${userId}-${year}-${pad2(month)}-${pad2(day)}${suffix}@rotapro.app`;
}

function vtimezone(tzid: string): string[] {
  if (tzid === "Asia/Kolkata" || tzid === "Asia/Calcutta") {
    return [
      "BEGIN:VTIMEZONE",
      "TZID:Asia/Kolkata",
      "X-LIC-LOCATION:Asia/Kolkata",
      "BEGIN:STANDARD",
      "TZOFFSETFROM:+0530",
      "TZOFFSETTO:+0530",
      "TZNAME:IST",
      "DTSTART:19700101T000000",
      "END:STANDARD",
      "END:VTIMEZONE",
    ];
  }
  return [
    "BEGIN:VTIMEZONE",
    `TZID:${tzid}`,
    `X-LIC-LOCATION:${tzid}`,
    "BEGIN:STANDARD",
    "TZOFFSETFROM:+0000",
    "TZOFFSETTO:+0000",
    "TZNAME:UTC",
    "DTSTART:19700101T000000",
    "END:STANDARD",
    "END:VTIMEZONE",
  ];
}

function cellHours(cell: ScheduleCell): number {
  const def = lookupShift(cell.raw_code) ?? shiftByType(cell.normalized_type);
  if (def.category === "leave") return 0;
  if (cell.is_split_shift && cell.split_segments?.length) {
    return cell.split_segments.reduce((a, s) => a + hoursBetween(s.start, s.end), 0);
  }
  return hoursBetween(cell.start ?? def.start, cell.end ?? def.end, def.isOvernight);
}

export function cumulativeHours(extraction: RotaExtractionResult, uptoDay?: number): number {
  return extraction.schedule
    .filter((c) => (uptoDay ? c.day <= uptoDay : true))
    .reduce((a, c) => a + cellHours(c), 0);
}

function vevent(opts: {
  cell: ScheduleCell;
  year: number;
  month: number;
  userId: string;
  sequence: number;
  tzid: string;
  stamp: string;
  privacy: PrivacySettings;
  metadata: RotaExtractionResult["metadata"];
  monthlyHours: number;
}): string[] {
  const { cell, year, month, userId, sequence, tzid, stamp, privacy, metadata, monthlyHours } = opts;
  const def = lookupShift(cell.raw_code) ?? shiftByType(cell.normalized_type);
  const isLeave = LEAVE_TYPES.includes(cell.normalized_type) || def.isAllDay;

  if (isLeave && privacy.omitLeavesFromCalendar) return [];

  const lines: string[] = ["BEGIN:VEVENT"];
  const uid = eventUid(userId, year, month, cell.day);
  lines.push(`UID:${uid}`);
  lines.push(`SEQUENCE:${sequence}`);
  lines.push(`DTSTAMP:${stamp}`);
  lines.push("STATUS:CONFIRMED");
  lines.push("TRANSP:OPAQUE");

  const hours = cellHours(cell);
  const unit = metadata.ward_unit ? ` · ${metadata.ward_unit}` : "";
  const summary = isLeave ? `${def.label} (${def.code})` : `${def.label} (${cell.raw_code})${unit}`;
  lines.push(`SUMMARY:${escapeText(summary)}`);

  const desc = [
    `Shift: ${def.label} [${cell.raw_code}]`,
    metadata.ward_unit ? `Unit: ${metadata.ward_unit}` : null,
    metadata.staff_name ? `Staff: ${metadata.staff_name}` : null,
    metadata.staff_id ? `ID: ${metadata.staff_id}` : null,
    isLeave ? "All-day hospital leave / off" : `Gross hours: ${formatHours(hours)}`,
    `Month to date: ${formatHours(monthlyHours)} duty hours`,
    cell.notes ? `Note: ${cell.notes}` : null,
    "Generated by RotaPro Enterprise · RFC 5545",
  ]
    .filter(Boolean)
    .join("\\n");
  lines.push(`DESCRIPTION:${escapeText(desc.replace(/\\n/g, "\n")).replace(/\n/g, "\\n")}`);
  lines.push(`CATEGORIES:${def.category.toUpperCase()},${def.normalizedType}`);
  lines.push(`COLOR:${def.color}`);

  if (isLeave) {
    const next = addDays(year, month, cell.day, 1);
    lines.push(`DTSTART;VALUE=DATE:${dateValue(year, month, cell.day)}`);
    lines.push(`DTEND;VALUE=DATE:${dateValue(next.year, next.month, next.day)}`);
    lines.push("X-MICROSOFT-CDO-ALLDAYEVENT:TRUE");
  } else if (cell.is_split_shift && (cell.split_segments?.length ?? 0) > 0) {
    // Split duties are emitted as a parent + we also return extra events via suffix.
    lines.length = 0;
    return splitEvents(opts);
  } else {
    const start = cell.start ?? def.start;
    const end = cell.end ?? def.end;
    const overnight = def.isOvernight || hoursBetween(start, end) < 0 || end <= start;
    const endDate = overnight ? addDays(year, month, cell.day, 1) : { year, month, day: cell.day };
    lines.push(`DTSTART;TZID=${tzid}:${localStamp(year, month, cell.day, start)}`);
    lines.push(`DTEND;TZID=${tzid}:${localStamp(endDate.year, endDate.month, endDate.day, end)}`);
    if (privacy.includeAlarms && privacy.alarmMinutes > 0 && def.alarmMinutes !== 0) {
      const mins = def.alarmMinutes || privacy.alarmMinutes;
      lines.push("BEGIN:VALARM");
      lines.push("ACTION:DISPLAY");
      lines.push(`TRIGGER:-PT${mins}M`);
      lines.push(`DESCRIPTION:${escapeText(`${def.label} starts in ${mins} minutes`)}`);
      lines.push("END:VALARM");
    }
  }

  lines.push("END:VEVENT");
  return lines;
}

function splitEvents(opts: Parameters<typeof vevent>[0]): string[] {
  const { cell, year, month, userId, sequence, tzid, stamp, privacy } = opts;
  const def = lookupShift(cell.raw_code) ?? shiftByType(cell.normalized_type);
  const segs = cell.split_segments ?? def.splitSegments ?? [];
  const out: string[] = [];
  segs.forEach((seg, idx) => {
    const uid = eventUid(userId, year, month, cell.day, `-s${idx + 1}`);
    out.push("BEGIN:VEVENT");
    out.push(`UID:${uid}`);
    out.push(`SEQUENCE:${sequence}`);
    out.push(`DTSTAMP:${stamp}`);
    out.push(`SUMMARY:${escapeText(`${def.label} · ${seg.title} (${cell.raw_code})`)}`);
    out.push(`DTSTART;TZID=${tzid}:${localStamp(year, month, cell.day, seg.start)}`);
    out.push(`DTEND;TZID=${tzid}:${localStamp(year, month, cell.day, seg.end)}`);
    out.push(`DESCRIPTION:${escapeText(`Split segment ${idx + 1} of ${segs.length}`)}`);
    out.push("STATUS:CONFIRMED");
    if (privacy.includeAlarms && privacy.alarmMinutes > 0) {
      out.push("BEGIN:VALARM");
      out.push("ACTION:DISPLAY");
      out.push(`TRIGGER:-PT${privacy.alarmMinutes}M`);
      out.push(`DESCRIPTION:${escapeText(`${seg.title} starts soon`)}`);
      out.push("END:VALARM");
    }
    out.push("END:VEVENT");
  });
  return out;
}

export function generateIcs(opts: {
  extraction: RotaExtractionResult;
  profile: NurseProfile;
  sequence: number;
  privacy: PrivacySettings;
  calendarName?: string;
}): string {
  const { extraction, profile, sequence, privacy } = opts;
  const { detected_year: year, detected_month: month } = extraction.metadata;
  const tzid = profile.timezone || "Asia/Kolkata";
  const stamp = utcStamp();
  const calName =
    opts.calendarName ??
    `RotaPro – ${extraction.metadata.staff_name || profile.name} ${monthName(month)} ${year}`;

  const lines: string[] = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    `PRODID:${PRODID}`,
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `X-WR-CALNAME:${escapeText(calName)}`,
    `X-WR-TIMEZONE:${tzid}`,
    "X-WR-CALDESC:Hospital duty rota generated by RotaPro Enterprise with deterministic UIDs and incremental SEQUENCE.",
    `X-ROTAPRO-SEQUENCE:${sequence}`,
    `X-ROTAPRO-STAFF:${escapeText(profile.staffId || extraction.metadata.staff_id || "")}`,
    ...vtimezone(tzid),
  ];

  const monthlyHours = cumulativeHours(extraction);

  for (const cell of extraction.schedule) {
    const eventLines = vevent({
      cell,
      year,
      month,
      userId: profile.userId,
      sequence,
      tzid,
      stamp,
      privacy,
      metadata: extraction.metadata,
      monthlyHours,
    });
    lines.push(...eventLines);
  }

  lines.push("END:VCALENDAR");
  return lines.map(fold).join(CRLF) + CRLF;
}

export function icsFilename(extraction: RotaExtractionResult): string {
  const { staff_name, detected_year, detected_month } = extraction.metadata;
  const slug = (staff_name || "rota").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "");
  return `${slug}-${detected_year}-${pad2(detected_month)}.ics`;
}
