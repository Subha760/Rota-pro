import type {
  DayOfWeek,
  RotaExtractionResult,
  ScheduleCell,
  ValidationIssue,
  ValidationResult,
} from "@/types/rota";
import { CONFIDENCE_THRESHOLD, LOOKALIKE_PAIRS } from "@/types/rota";
import { lookupShift, normalizeCode } from "@/lib/shift-definitions";

export const DOW: DayOfWeek[] = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

export function dayOfWeek(year: number, month: number, day: number): DayOfWeek {
  return DOW[new Date(year, month - 1, day).getDay()];
}

export function isWeekend(year: number, month: number, day: number): boolean {
  const d = new Date(year, month - 1, day).getDay();
  return d === 0 || d === 6;
}

/**
 * Strict Date Anchor Rule:
 * Schedules MUST map from Day 1 of the detected month through the true
 * last day (28/29/30/31). Every extracted day_of_week is cross-checked
 * against `new Date(year, month - 1, day).getDay()`. Table shifts and
 * missing columns are auto-rectified.
 */
export function validateAndRectify(extraction: RotaExtractionResult): ValidationResult {
  const { detected_year: year, detected_month: month } = extraction.metadata;
  const total = daysInMonth(year, month);
  const issues: ValidationIssue[] = [];
  const byDay = new Map<number, ScheduleCell>();

  for (const cell of extraction.schedule) {
    if (cell.day < 1 || cell.day > 31) {
      issues.push({
        day: cell.day,
        kind: "boundary",
        message: `Day ${cell.day} is outside 1–31 and was dropped.`,
        auto_rectified: true,
      });
      continue;
    }
    byDay.set(cell.day, cell);
  }

  // Detect a consistent DOW offset (table shifted left/right).
  const offsets: number[] = [];
  for (const cell of byDay.values()) {
    if (cell.day > total) continue;
    const expected = dayOfWeek(year, month, cell.day);
    const actualIdx = DOW.indexOf(cell.day_of_week);
    const expectedIdx = DOW.indexOf(expected);
    if (actualIdx >= 0 && cell.day_of_week !== expected) {
      offsets.push((actualIdx - expectedIdx + 7) % 7);
    }
  }

  let tableShift = 0;
  let table_shift_detected = false;
  if (offsets.length >= 3) {
    const freq = new Map<number, number>();
    for (const o of offsets) freq.set(o, (freq.get(o) ?? 0) + 1);
    const [best, count] = [...freq.entries()].sort((a, b) => b[1] - a[1])[0];
    if (count >= Math.ceil(offsets.length * 0.6) && best !== 0) {
      tableShift = best;
      table_shift_detected = true;
    }
  }

  const rectifiedSchedule: ScheduleCell[] = [];

  for (let day = 1; day <= total; day++) {
    const expectedDow = dayOfWeek(year, month, day);
    let cell = byDay.get(day);

    if (!cell) {
      issues.push({
        day,
        kind: "missing_day",
        message: `Missing Day ${day}. Inserted OFF pending confirmation.`,
        expected: expectedDow,
        auto_rectified: true,
      });
      cell = {
        day,
        day_of_week: expectedDow,
        raw_code: "OFF",
        normalized_type: "OFF",
        is_split_shift: false,
        confidence: 0.4,
        is_ambiguous: true,
        notes: "Auto-inserted: missing column/cell",
      };
    } else {
      const reported = cell.day_of_week;
      if (reported !== expectedDow) {
        issues.push({
          day,
          kind: "dow_mismatch",
          message: `Roster listed ${reported} for Day ${day} but calendar math is ${expectedDow}${
            tableShift ? ` (table shift ${tableShift} detected, rectified)` : ""
          }.`,
          expected: expectedDow,
          actual: reported,
          auto_rectified: true,
        });
      }
      if (cell.confidence < CONFIDENCE_THRESHOLD) {
        issues.push({
          day,
          kind: "low_confidence",
          message: `Confidence ${(cell.confidence * 100).toFixed(0)}% below 92% threshold.`,
          auto_rectified: false,
        });
      }
      const code = normalizeCode(cell.raw_code);
      for (const [a, b] of LOOKALIKE_PAIRS) {
        if (code === a || code === b) {
          const twin = code === a ? b : a;
          if (cell.confidence < 0.97) {
            issues.push({
              day,
              kind: "lookalike",
              message: `OCR lookalike risk: ${a} vs ${b} (read as ${cell.raw_code}).`,
              actual: cell.raw_code,
              expected: twin,
              auto_rectified: false,
            });
          }
        }
      }
    }

    const def = lookupShift(cell.raw_code);
    rectifiedSchedule.push({
      ...cell,
      day,
      day_of_week: expectedDow,
      normalized_type: def?.normalizedType ?? cell.normalized_type,
      is_split_shift: def?.normalizedType === "SPLIT" || cell.is_split_shift,
      split_segments: def?.splitSegments ?? cell.split_segments,
      start: def?.start ?? cell.start,
      end: def?.end ?? cell.end,
      is_ambiguous:
        cell.is_ambiguous ||
        cell.confidence < CONFIDENCE_THRESHOLD ||
        !lookupShift(cell.raw_code),
    });
  }

  for (const cell of byDay.values()) {
    if (cell.day > total) {
      issues.push({
        day: cell.day,
        kind: "extra_day",
        message: `Day ${cell.day} exceeds ${total} days in ${year}-${String(month).padStart(2, "0")} and was dropped.`,
        auto_rectified: true,
      });
    }
  }

  const rectified: RotaExtractionResult = {
    metadata: {
      ...extraction.metadata,
      detected_year: year,
      detected_month: month,
      total_days: total,
    },
    schedule: rectifiedSchedule,
  };

  return {
    ok: issues.every((i) => i.kind !== "low_confidence" && i.kind !== "lookalike"),
    issues,
    rectified,
    table_shift_detected,
  };
}

export function buildEmptyMonth(
  year: number,
  month: number,
  staffName: string,
  staffId?: string,
  ward?: string
): RotaExtractionResult {
  const total = daysInMonth(year, month);
  return {
    metadata: {
      detected_month: month,
      detected_year: year,
      staff_name: staffName,
      staff_id: staffId,
      ward_unit: ward,
      total_days: total,
    },
    schedule: Array.from({ length: total }, (_, i) => {
      const day = i + 1;
      return {
        day,
        day_of_week: dayOfWeek(year, month, day),
        raw_code: "OFF",
        normalized_type: "OFF" as const,
        is_split_shift: false,
        confidence: 1,
        is_ambiguous: false,
      };
    }),
  };
}
