import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import { nanoid } from "nanoid";
import type {
  CustomShiftDefinition,
  NurseProfile,
  PrivacySettings,
  RotaDocument,
} from "@/types/rota";

interface RotaProDB extends DBSchema {
  profiles: {
    key: string;
    value: NurseProfile;
  };
  rotas: {
    key: string;
    value: RotaDocument;
    indexes: { "by-month": [number, number] };
  };
  settings: {
    key: string;
    value: {
      id: string;
      privacy: PrivacySettings;
      customShifts: CustomShiftDefinition[];
      engine: "autopilot" | "inspector";
      webcalToken: string;
    };
  };
}

const DB_NAME = "rotapro-enterprise";
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<RotaProDB>> | null = null;

function getDb() {
  if (typeof window === "undefined") {
    throw new Error("IndexedDB is browser-only");
  }
  if (!dbPromise) {
    dbPromise = openDB<RotaProDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("profiles")) {
          db.createObjectStore("profiles", { keyPath: "userId" });
        }
        if (!db.objectStoreNames.contains("rotas")) {
          const rotas = db.createObjectStore("rotas", { keyPath: "id" });
          rotas.createIndex("by-month", ["year", "month"]);
        }
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "id" });
        }
      },
    });
  }
  return dbPromise;
}

export const DEFAULT_PRIVACY: PrivacySettings = {
  ephemeralProcessing: false,
  redactColleagues: true,
  omitLeavesFromCalendar: false,
  includeAlarms: true,
  alarmMinutes: 90,
};

export async function getProfile(): Promise<NurseProfile | null> {
  const db = await getDb();
  const all = await db.getAll("profiles");
  return all[0] ?? null;
}

export async function saveProfile(profile: NurseProfile): Promise<void> {
  const db = await getDb();
  await db.put("profiles", { ...profile, updatedAt: new Date().toISOString() });
}

export function createDefaultProfile(partial?: Partial<NurseProfile>): NurseProfile {
  const now = new Date().toISOString();
  return {
    userId: partial?.userId || `np-${nanoid(10)}`,
    name: partial?.name || "",
    staffId: partial?.staffId || "",
    ward: partial?.ward || "",
    hospital: partial?.hospital || "",
    timezone: partial?.timezone || "Asia/Kolkata",
    identityTokens: partial?.identityTokens || [],
    createdAt: partial?.createdAt || now,
    updatedAt: now,
  };
}

export async function getSettings() {
  const db = await getDb();
  const existing = await db.get("settings", "default");
  if (existing) return existing;
  const fresh = {
    id: "default",
    privacy: DEFAULT_PRIVACY,
    customShifts: [] as CustomShiftDefinition[],
    engine: "autopilot" as const,
    webcalToken: nanoid(18),
  };
  await db.put("settings", fresh);
  return fresh;
}

export async function saveSettings(
  patch: Partial<Awaited<ReturnType<typeof getSettings>>>
) {
  const db = await getDb();
  const current = await getSettings();
  const next = { ...current, ...patch, id: "default" };
  await db.put("settings", next);
  return next;
}

export async function saveRota(doc: RotaDocument): Promise<void> {
  const db = await getDb();
  await db.put("rotas", doc);
}

export async function getRota(id: string): Promise<RotaDocument | null> {
  const db = await getDb();
  return (await db.get("rotas", id)) ?? null;
}

export async function getRotaForMonth(year: number, month: number): Promise<RotaDocument | null> {
  const db = await getDb();
  const hits = await db.getAllFromIndex("rotas", "by-month", [year, month]);
  if (!hits.length) return null;
  return hits.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
}

export async function listRotas(): Promise<RotaDocument[]> {
  const db = await getDb();
  const all = await db.getAll("rotas");
  return all.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function nextSequence(year: number, month: number): Promise<number> {
  const prev = await getRotaForMonth(year, month);
  return (prev?.sequence ?? 0) + 1;
}

export async function wipeDocuments(): Promise<void> {
  const db = await getDb();
  const all = await db.getAll("rotas");
  const tx = db.transaction("rotas", "readwrite");
  for (const r of all) {
    await tx.store.put({ ...r, documentDataUrl: undefined });
  }
  await tx.done;
}

export function identityMatches(profile: NurseProfile, haystack: string): boolean {
  const tokens = [
    profile.name,
    profile.staffId,
    profile.ward,
    ...profile.identityTokens,
  ]
    .filter(Boolean)
    .map((t) => t.toLowerCase());
  const hay = haystack.toLowerCase();
  return tokens.some((t) => t.length >= 2 && hay.includes(t));
}
