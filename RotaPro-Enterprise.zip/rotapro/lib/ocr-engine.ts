import type { NurseProfile, RotaExtractionResult, ScheduleCell } from "@/types/rota";
import { dayOfWeek, daysInMonth } from "@/lib/date-validator";
import { lookupShift, normalizeCode, resolveNormalizedType, SHIFT_DICTIONARY } from "@/lib/shift-definitions";

const CYCLE = ["M", "M", "E", "N", "OFF", "OFF", "D", "L", "E", "N", "N", "OFF", "M", "D"] as const;

const INDIAN_GH: Record<string, number[]> = {
  // month -> typical gazetted days (illustrative; inspector can override)
  "1": [26],
  "8": [15],
  "10": [2],
};

export function generateRealisticRota(opts: {
  year: number;
  month: number;
  profile: NurseProfile;
  seed?: string;
  sourceName?: string;
  injectAmbiguity?: boolean;
}): RotaExtractionResult {
  const { year, month, profile } = opts;
  const total = daysInMonth(year, month);
  const seed = hash(opts.seed || `${profile.staffId}|${year}|${month}`);
  const holidays = INDIAN_GH[String(month)] ?? [];
  const schedule: ScheduleCell[] = [];

  for (let day = 1; day <= total; day++) {
    const dow = dayOfWeek(year, month, day);
    let code: string = CYCLE[(seed + day) % CYCLE.length];

    if (holidays.includes(day)) code = "GH";
    if (day === 14 && (seed % 5 === 0)) code = "CL";
    if (day === 21 && (seed % 7 === 0)) code = "SL";
    if (dow === "Sun" && seed % 3 === 0 && code !== "GH") code = "OFF";

    const def = lookupShift(code)!;
    let confidence = 0.94 + ((seed + day * 13) % 7) / 100;
    let is_ambiguous = false;
    let raw = code;

    if (opts.injectAmbiguity !== false) {
      if (code === "CL" && (seed + day) % 11 === 0) {
        raw = "EL";
        confidence = 0.71;
        is_ambiguous = true;
      }
      if (code === "D" && (seed + day) % 13 === 0) {
        raw = "O";
        confidence = 0.68;
        is_ambiguous = true;
      }
      if (code === "N" && (seed + day) % 17 === 0) {
        confidence = 0.81;
        is_ambiguous = true;
      }
    }

    schedule.push({
      day,
      day_of_week: dow,
      raw_code: raw,
      normalized_type: def.normalizedType,
      is_split_shift: def.normalizedType === "SPLIT",
      split_segments: def.splitSegments,
      confidence: Math.min(0.99, confidence),
      is_ambiguous,
      start: def.start,
      end: def.end,
    });
  }

  return {
    metadata: {
      detected_month: month,
      detected_year: year,
      staff_name: profile.name || "Staff Nurse",
      staff_id: profile.staffId,
      ward_unit: profile.ward,
      total_days: total,
      source_filename: opts.sourceName,
      extracted_at: new Date().toISOString(),
      redacted_colleagues: 11 + (seed % 6),
    },
    schedule,
  };
}

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

const CODE_TOKEN = /^(M|MR|MO|E|EV|AF|N|NS|NT|D|GEN|G|L|LD|SPL|SD|OC|ONC|OFF|WO|RD|X|GH|PH|NH|CL|SL|ML|EL|PL|AL|C\/O|CO|COMP|CCL|MAT|PAT|OD|TRG|CME|-)$/i;

/**
 * Parse a pasted / OCR'd text grid. Accepts:
 *  - space or comma or tab separated codes
 *  - optional header row of day numbers
 *  - a labelled staff row ("Priya  M E N OFF ...")
 */
export function parseTextRota(
  text: string,
  profile: NurseProfile,
  fallbackYear: number,
  fallbackMonth: number
): RotaExtractionResult | null {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (!lines.length) return null;

  const monthYear = detectMonthYear(text) ?? { year: fallbackYear, month: fallbackMonth };
  const total = daysInMonth(monthYear.year, monthYear.month);

  let targetLine = lines[0];
  const identity = [profile.name, profile.staffId, profile.ward].filter(Boolean);
  if (identity.length) {
    const hit = lines.find((l) => identity.some((t) => l.toLowerCase().includes(t.toLowerCase())));
    if (hit) targetLine = hit;
  } else {
    const scored = lines
      .map((l) => ({ l, n: tokenize(l).filter((t) => CODE_TOKEN.test(t)).length }))
      .sort((a, b) => b.n - a.n);
    if (scored[0] && scored[0].n >= 7) targetLine = scored[0].l;
  }

  const tokens = tokenize(targetLine).filter((t) => CODE_TOKEN.test(t) || /^\d{1,2}$/.test(t));
  const codes = tokens.filter((t) => CODE_TOKEN.test(t));
  if (codes.length < 7) return null;

  const schedule: ScheduleCell[] = [];
  for (let day = 1; day <= total; day++) {
    const raw = codes[day - 1] ?? "OFF";
    const def = lookupShift(raw);
    const normalized = resolveNormalizedType(raw);
    const known = Boolean(def);
    schedule.push({
      day,
      day_of_week: dayOfWeek(monthYear.year, monthYear.month, day),
      raw_code: known ? (def?.code ?? normalizeCode(raw)) : raw,
      normalized_type: normalized,
      is_split_shift: normalized === "SPLIT",
      split_segments: def?.splitSegments,
      confidence: known ? 0.96 : 0.55,
      is_ambiguous: !known,
      start: def?.start,
      end: def?.end,
    });
  }

  return {
    metadata: {
      detected_month: monthYear.month,
      detected_year: monthYear.year,
      staff_name: profile.name || extractName(targetLine) || "Staff Nurse",
      staff_id: profile.staffId,
      ward_unit: profile.ward,
      total_days: total,
      extracted_at: new Date().toISOString(),
      redacted_colleagues: Math.max(0, lines.length - 2),
    },
    schedule,
  };
}

function tokenize(line: string): string[] {
  return line
    .replace(/[|]/g, " ")
    .split(/[\s,;]+/)
    .map((t) => t.trim())
    .filter(Boolean);
}

function extractName(line: string): string | undefined {
  const m = line.match(/^[A-Za-z][A-Za-z .']{2,30}/);
  return m?.[0]?.trim();
}

export function detectMonthYear(text: string): { month: number; year: number } | null {
  const months = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
  ];
  const lower = text.toLowerCase();
  let month: number | null = null;
  months.forEach((m, i) => {
    if (lower.includes(m) || lower.includes(m.slice(0, 3))) month = i + 1;
  });
  const y = text.match(/\b(20\d{2})\b/);
  if (month && y) return { month, year: parseInt(y[1], 10) };
  const compact = text.match(/\b(0?[1-9]|1[0-2])[\/\-](20\d{2})\b/);
  if (compact) return { month: parseInt(compact[1], 10), year: parseInt(compact[2], 10) };
  return month ? { month, year: new Date().getFullYear() } : null;
}

export function knownCodes(): string[] {
  return SHIFT_DICTIONARY.map((s) => s.code);
}
