import type { CustomShiftDefinition, NormalizedShiftType, ShiftDefinition } from "@/types/rota";
import { hoursBetween } from "@/lib/utils";

const DEFAULT_ALARM = 90;

function work(
  partial: Omit<ShiftDefinition, "category" | "hours" | "isAllDay" | "omitFromCalendar" | "alarmMinutes" | "id"> & {
    alarmMinutes?: number;
  }
): ShiftDefinition {
  const overnight = partial.isOvernight;
  const hours = partial.splitSegments
    ? partial.splitSegments.reduce((acc, s) => acc + hoursBetween(s.start, s.end, false), 0)
    : hoursBetween(partial.start, partial.end, overnight);
  return {
    id: partial.code,
    category: "work",
    hours,
    isAllDay: false,
    omitFromCalendar: false,
    alarmMinutes: partial.alarmMinutes ?? DEFAULT_ALARM,
    ...partial,
  };
}

function leave(
  partial: Omit<ShiftDefinition, "category" | "hours" | "isOvernight" | "isAllDay" | "omitFromCalendar" | "alarmMinutes" | "start" | "end" | "id">
): ShiftDefinition {
  return {
    id: partial.code,
    category: "leave",
    hours: 0,
    isOvernight: false,
    isAllDay: true,
    omitFromCalendar: false,
    alarmMinutes: 0,
    start: "00:00",
    end: "23:59",
    ...partial,
  };
}

export const SHIFT_DICTIONARY: ShiftDefinition[] = [
  work({
    code: "M",
    aliases: ["M", "MR", "MO", "MORNING", "AM"],
    label: "Morning Shift",
    normalizedType: "MORNING",
    start: "07:00",
    end: "15:00",
    color: "#f59e0b",
    isOvernight: false,
    description: "Standard morning duty — 07:00 to 15:00",
  }),
  work({
    code: "E",
    aliases: ["E", "EV", "AF", "EVE", "EVENING", "AFTERNOON", "PM"],
    label: "Evening / Afternoon Shift",
    normalizedType: "EVENING",
    start: "13:00",
    end: "21:00",
    color: "#f97316",
    isOvernight: false,
    description: "Evening / afternoon duty — 13:00 to 21:00",
  }),
  work({
    code: "N",
    aliases: ["N", "NS", "NT", "NIGHT", "NOC"],
    label: "Night Shift",
    normalizedType: "NIGHT",
    start: "20:30",
    end: "08:00",
    color: "#6366f1",
    isOvernight: true,
    description: "Overnight duty — 20:30 Day N to 08:00 Day N+1 with rest-period tracking",
  }),
  work({
    code: "D",
    aliases: ["D", "GEN", "G", "GD", "GENERAL", "DAY"],
    label: "General Day Shift",
    normalizedType: "GENERAL_DAY",
    start: "08:30",
    end: "17:00",
    color: "#0ea5e9",
    isOvernight: false,
    description: "General / OPD day duty — 08:30 to 17:00",
  }),
  work({
    code: "L",
    aliases: ["L", "LD", "LONG", "LONGDAY"],
    label: "Long Day",
    normalizedType: "LONG_DAY",
    start: "07:30",
    end: "20:30",
    color: "#14b8a6",
    isOvernight: false,
    description: "Long day covering morning through evening — 07:30 to 20:30",
  }),
  work({
    code: "SPL",
    aliases: ["SPL", "SD", "SPLIT", "SP"],
    label: "Split Duty",
    normalizedType: "SPLIT",
    start: "08:00",
    end: "20:00",
    color: "#d946ef",
    isOvernight: false,
    splitSegments: [
      { start: "08:00", end: "12:00", title: "Split A" },
      { start: "16:00", end: "20:00", title: "Split B" },
    ],
    description: "Dual interval split duty — 08:00–12:00 and 16:00–20:00",
  }),
  work({
    code: "OC",
    aliases: ["OC", "ONC", "ONCALL", "STANDBY", "SBY"],
    label: "On-Call / Standby",
    normalizedType: "ON_CALL",
    start: "08:00",
    end: "08:00",
    color: "#a78bfa",
    isOvernight: true,
    alarmMinutes: 0,
    description: "Background standby / on-call coverage — 24h window",
  }),
  leave({
    code: "OFF",
    aliases: ["OFF", "WO", "RD", "X", "WEEKLYOFF", "REST", "-"],
    label: "Weekly Off / Rest Day",
    normalizedType: "OFF",
    color: "#64748b",
    description: "Weekly off / rest day — exportable as all-day or omittable",
  }),
  leave({
    code: "GH",
    aliases: ["GH", "PH", "NH", "HOLIDAY", "GAZETTED"],
    label: "Gazetted / Public Holiday",
    normalizedType: "GH",
    color: "#fb7185",
    description: "Gazetted, public, or national holiday",
  }),
  leave({
    code: "CL",
    aliases: ["CL", "CASUAL"],
    label: "Casual Leave",
    normalizedType: "CL",
    color: "#22d3ee",
    description: "Casual leave",
  }),
  leave({
    code: "SL",
    aliases: ["SL", "ML", "SICK", "MEDICAL"],
    label: "Sick / Medical Leave",
    normalizedType: "SL",
    color: "#f43f5e",
    description: "Sick leave or medical leave",
  }),
  leave({
    code: "EL",
    aliases: ["EL", "PL", "AL", "EARNED", "PRIVILEGE", "ANNUAL"],
    label: "Earned / Privilege / Annual Leave",
    normalizedType: "EL",
    color: "#34d399",
    description: "Earned, privilege, or annual leave",
  }),
  leave({
    code: "C/O",
    aliases: ["C/O", "CO", "COMP", "COMPOFF", "C.O", "C.O."],
    label: "Compensatory Off",
    normalizedType: "COMP_OFF",
    color: "#84cc16",
    description: "Compensatory off against overtime or holiday duty",
  }),
  leave({
    code: "MAT",
    aliases: ["CCL", "MAT", "PAT", "MATERNITY", "PATERNITY", "CHILDCARE"],
    label: "Child Care / Maternity / Paternity",
    normalizedType: "MATERNITY",
    color: "#f472b6",
    description: "Child-care, maternity, or paternity leave",
  }),
  work({
    code: "OD",
    aliases: ["OD", "TRG", "CME", "TRAINING", "ONDUTY"],
    label: "On Duty / Training",
    normalizedType: "ON_DUTY",
    start: "09:00",
    end: "17:00",
    color: "#38bdf8",
    isOvernight: false,
    description: "Official hospital duty, training, or CME — 09:00 to 17:00",
  }),
];

const ALIAS_INDEX = new Map<string, ShiftDefinition>();
for (const def of SHIFT_DICTIONARY) {
  for (const alias of def.aliases) {
    ALIAS_INDEX.set(normalizeCode(alias), def);
  }
}

export function normalizeCode(raw: string): string {
  return raw
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "")
    .replace(/\./g, "")
    .replace(/[_-]/g, "");
}

export function lookupShift(raw: string, custom: CustomShiftDefinition[] = []): ShiftDefinition | undefined {
  const key = normalizeCode(raw);
  const customHit = custom.find((c) => normalizeCode(c.code) === key);
  if (customHit) {
    return {
      ...customHit,
      aliases: [customHit.code],
      category: customHit.isAllDay ? "leave" : "work",
      hours: customHit.splitSegments
        ? customHit.splitSegments.reduce((a, s) => a + hoursBetween(s.start, s.end), 0)
        : hoursBetween(customHit.start, customHit.end, customHit.isOvernight),
      description: customHit.label,
    };
  }
  return ALIAS_INDEX.get(key);
}

export function resolveNormalizedType(raw: string, custom: CustomShiftDefinition[] = []): NormalizedShiftType {
  return lookupShift(raw, custom)?.normalizedType ?? "CUSTOM";
}

export function shiftByType(type: NormalizedShiftType): ShiftDefinition {
  return SHIFT_DICTIONARY.find((s) => s.normalizedType === type) ?? SHIFT_DICTIONARY[0];
}

export const PALETTE_CODES = ["M", "E", "N", "D", "L", "SPL", "OFF", "GH", "CL", "SL", "EL", "C/O"] as const;

export function badgeStyle(color: string): { background: string; color: string; border: string } {
  return {
    background: `${color}22`,
    color,
    border: `${color}55`,
  };
}

export const WORK_TYPES: NormalizedShiftType[] = [
  "MORNING",
  "EVENING",
  "NIGHT",
  "GENERAL_DAY",
  "LONG_DAY",
  "SPLIT",
  "ON_CALL",
  "ON_DUTY",
  "CUSTOM",
];

export const LEAVE_TYPES: NormalizedShiftType[] = [
  "OFF",
  "GH",
  "CL",
  "SL",
  "EL",
  "COMP_OFF",
  "MATERNITY",
];
