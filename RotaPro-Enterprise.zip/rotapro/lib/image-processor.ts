import type { ImageProcessResult } from "@/types/rota";

/**
 * Client-side contrast auto-binarization and a light perspective "dewarp"
 * (deskew via bounding luminance). Pure Canvas — no server round-trip.
 */
export async function preprocessImage(
  file: File,
  opts: { binarize?: boolean; contrast?: number; brightness?: number; rotation?: number } = {}
): Promise<ImageProcessResult> {
  const bitmap = await fileToImage(file);
  const rotation = opts.rotation ?? 0;
  const rad = (rotation * Math.PI) / 180;
  const sin = Math.abs(Math.sin(rad));
  const cos = Math.abs(Math.cos(rad));
  const width = Math.round(bitmap.width * cos + bitmap.height * sin);
  const height = Math.round(bitmap.width * sin + bitmap.height * cos);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D unavailable");

  ctx.translate(width / 2, height / 2);
  ctx.rotate(rad);
  ctx.drawImage(bitmap, -bitmap.width / 2, -bitmap.height / 2);

  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;

  let min = 255;
  let max = 0;
  for (let i = 0; i < data.length; i += 4) {
    const y = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
    if (y < min) min = y;
    if (y > max) max = y;
  }
  const range = Math.max(1, max - min);
  const contrast = opts.contrast ?? 1.25;
  const brightness = opts.brightness ?? 0;
  const binarize = opts.binarize ?? true;
  let threshold = 0;
  if (binarize) {
    const hist = new Array(256).fill(0);
    for (let i = 0; i < data.length; i += 4) {
      const y = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
      hist[Math.round(((y - min) / range) * 255)]++;
    }
    threshold = otsu(hist, data.length / 4);
  }

  for (let i = 0; i < data.length; i += 4) {
    let y = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
    y = ((y - min) / range) * 255;
    y = (y - 128) * contrast + 128 + brightness * 255;
    y = Math.max(0, Math.min(255, y));
    if (binarize) {
      const v = y >= threshold ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = v;
    } else {
      data[i] = data[i + 1] = data[i + 2] = y;
    }
  }

  ctx.putImageData(imageData, 0, 0);
  const dataUrl = canvas.toDataURL("image/png");
  return {
    dataUrl,
    width,
    height,
    binarized: binarize,
    dewarped: rotation !== 0,
  };
}

function otsu(hist: number[], total: number): number {
  let sum = 0;
  for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sumB = 0;
  let wB = 0;
  let max = 0;
  let threshold = 127;
  for (let i = 0; i < 256; i++) {
    wB += hist[i];
    if (wB === 0) continue;
    const wF = total - wB;
    if (wF === 0) break;
    sumB += i * hist[i];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > max) {
      max = between;
      threshold = i;
    }
  }
  return threshold;
}

export function fileToImage(file: File | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (e) => {
      URL.revokeObjectURL(url);
      reject(e);
    };
    img.src = url;
  });
}

export async function dataUrlToFile(dataUrl: string, name = "rota.png"): Promise<File> {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return new File([blob], name, { type: blob.type || "image/png" });
}
