import type { RotaExtractionResult, SwapPayload, SwapSlot } from "@/types/rota";
import { LEAVE_TYPES, WORK_TYPES } from "@/lib/shift-definitions";
import { isoDate } from "@/lib/utils";

export function buildSwapPayload(
  hash: string,
  extraction: RotaExtractionResult
): SwapPayload {
  return {
    hash,
    profile: {
      name: extraction.metadata.staff_name,
      staffId: extraction.metadata.staff_id || "",
      ward: extraction.metadata.ward_unit || "",
    },
    month: extraction.metadata.detected_month,
    year: extraction.metadata.detected_year,
    schedule: extraction.schedule.map((c) => ({
      day: c.day,
      raw_code: c.raw_code,
      normalized_type: c.normalized_type,
    })),
    createdAt: new Date().toISOString(),
  };
}

export function findSwapSlots(self: SwapPayload, peer: SwapPayload): SwapSlot[] {
  if (self.month !== peer.month || self.year !== peer.year) return [];
  const peerMap = new Map(peer.schedule.map((c) => [c.day, c]));
  const slots: SwapSlot[] = [];

  for (const mine of self.schedule) {
    const theirs = peerMap.get(mine.day);
    if (!theirs) continue;
    const selfOff = LEAVE_TYPES.includes(mine.normalized_type);
    const peerOff = LEAVE_TYPES.includes(theirs.normalized_type);
    const selfWork = WORK_TYPES.includes(mine.normalized_type);
    const peerWork = WORK_TYPES.includes(theirs.normalized_type);
    const date = isoDate(self.year, self.month, mine.day);

    if (selfOff && peerWork) {
      slots.push({
        day: mine.day,
        date,
        selfCode: mine.raw_code,
        peerCode: theirs.raw_code,
        kind: "take",
        reason: `You are ${mine.raw_code} while ${peer.profile.name || "peer"} works ${theirs.raw_code} — conflict-free take.`,
      });
    } else if (selfWork && peerOff) {
      slots.push({
        day: mine.day,
        date,
        selfCode: mine.raw_code,
        peerCode: theirs.raw_code,
        kind: "give",
        reason: `You work ${mine.raw_code} while peer is ${theirs.raw_code} — conflict-free give.`,
      });
    } else if (selfWork && peerWork && mine.normalized_type !== theirs.normalized_type) {
      slots.push({
        day: mine.day,
        date,
        selfCode: mine.raw_code,
        peerCode: theirs.raw_code,
        kind: "mutual",
        reason: `Different duties (${mine.raw_code} ↔ ${theirs.raw_code}) — mutual swap candidate.`,
      });
    }
  }
  return slots;
}

export function encodeSwap(payload: SwapPayload): string {
  const json = JSON.stringify(payload);
  const b64 = typeof window === "undefined" ? Buffer.from(json).toString("base64") : btoa(json);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

export function decodeSwap(hash: string): SwapPayload | null {
  try {
    let b64 = hash.replace(/-/g, "+").replace(/_/g, "/");
    while (b64.length % 4) b64 += "=";
    const json = typeof window === "undefined" ? Buffer.from(b64, "base64").toString("utf8") : atob(b64);
    return JSON.parse(json) as SwapPayload;
  } catch {
    return null;
  }
}
