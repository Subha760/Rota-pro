import type { AnalyticsSnapshot, RotaExtractionResult, ScheduleCell } from "@/types/rota";
import { LEAVE_TYPES, WORK_TYPES, lookupShift, shiftByType } from "@/lib/shift-definitions";
import { isWeekend } from "@/lib/date-validator";
import { hoursBetween } from "@/lib/utils";

export function cellHours(cell: ScheduleCell): number {
  const def = lookupShift(cell.raw_code) ?? shiftByType(cell.normalized_type);
  if (LEAVE_TYPES.includes(cell.normalized_type) || def.category === "leave") return 0;
  if (cell.is_split_shift && cell.split_segments?.length) {
    return cell.split_segments.reduce((a, s) => a + hoursBetween(s.start, s.end), 0);
  }
  return hoursBetween(cell.start ?? def.start, cell.end ?? def.end, def.isOvernight);
}

export function computeAnalytics(extraction: RotaExtractionResult): AnalyticsSnapshot {
  const { detected_year: year, detected_month: month } = extraction.metadata;
  const hoursByType: Record<string, number> = {};
  let totalDutyHours = 0;
  let nightShiftCount = 0;
  let leaveDays = 0;
  let offDays = 0;
  let workDays = 0;
  let splitDays = 0;
  let weekendCoverage = 0;
  let weekendTotal = 0;

  let streak = 0;
  let consecutiveDaysMax = 0;

  const weeklyHours = [0, 0, 0, 0, 0, 0];

  for (const cell of extraction.schedule) {
    const h = cellHours(cell);
    hoursByType[cell.normalized_type] = (hoursByType[cell.normalized_type] ?? 0) + h;
    const isWork = WORK_TYPES.includes(cell.normalized_type) && h > 0;
    const isOff = cell.normalized_type === "OFF" || cell.normalized_type === "COMP_OFF";
    const isLeave = LEAVE_TYPES.includes(cell.normalized_type);

    if (isWork) {
      totalDutyHours += h;
      workDays += 1;
      streak += 1;
      consecutiveDaysMax = Math.max(consecutiveDaysMax, streak);
    } else {
      streak = 0;
    }
    if (cell.normalized_type === "NIGHT") nightShiftCount += 1;
    if (cell.is_split_shift || cell.normalized_type === "SPLIT") splitDays += 1;
    if (isOff) offDays += 1;
    if (isLeave && !isOff) leaveDays += 1;

    if (isWeekend(year, month, cell.day)) {
      weekendTotal += 1;
      if (isWork) weekendCoverage += 1;
    }

    const date = new Date(year, month - 1, cell.day);
    const week = Math.min(5, Math.floor((date.getDate() - 1) / 7));
    weeklyHours[week] += h;
  }

  const nightPenalty = Math.min(40, nightShiftCount * 4);
  const streakPenalty = Math.max(0, (consecutiveDaysMax - 5) * 8);
  const weekendPenalty = weekendTotal ? (weekendCoverage / weekendTotal) * 20 : 0;
  const restPeriodHealth = Math.max(
    0,
    Math.min(100, Math.round(100 - nightPenalty - streakPenalty - weekendPenalty))
  );

  return {
    totalDutyHours: Math.round(totalDutyHours * 10) / 10,
    nightShiftCount,
    consecutiveDaysMax,
    weekendCoverage,
    restPeriodHealth,
    leaveDays,
    offDays,
    workDays,
    splitDays,
    hoursByType,
    weeklyHours: weeklyHours.map((h) => Math.round(h * 10) / 10),
  };
}

export function diffSchedules(
  previous: RotaExtractionResult | null,
  next: RotaExtractionResult
): { changed: number; cells: ScheduleCell[] } {
  if (!previous) return { changed: 0, cells: next.schedule };
  const prevMap = new Map(previous.schedule.map((c) => [c.day, c]));
  let changed = 0;
  const cells = next.schedule.map((cell) => {
    const old = prevMap.get(cell.day);
    if (old && old.raw_code !== cell.raw_code) {
      changed += 1;
      return { ...cell, patched: true, previous_code: old.raw_code };
    }
    return cell;
  });
  return { changed, cells };
}
