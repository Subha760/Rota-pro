export type NormalizedShiftType =
  | "MORNING"
  | "EVENING"
  | "NIGHT"
  | "GENERAL_DAY"
  | "LONG_DAY"
  | "SPLIT"
  | "ON_CALL"
  | "OFF"
  | "GH"
  | "CL"
  | "SL"
  | "EL"
  | "COMP_OFF"
  | "MATERNITY"
  | "ON_DUTY"
  | "CUSTOM";

export type DayOfWeek = "Sun" | "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat";

export interface SplitSegment {
  start: string; // HH:mm
  end: string; // HH:mm
  title: string;
}

export interface CustomShiftDefinition {
  id: string;
  code: string;
  label: string;
  normalizedType: NormalizedShiftType;
  start: string;
  end: string;
  color: string;
  isOvernight: boolean;
  isAllDay: boolean;
  omitFromCalendar: boolean;
  alarmMinutes: number;
  splitSegments?: SplitSegment[];
}

export interface ShiftDefinition extends CustomShiftDefinition {
  aliases: string[];
  category: "work" | "leave" | "standby";
  hours: number;
  description: string;
}

export interface ScheduleCell {
  day: number;
  day_of_week: DayOfWeek;
  raw_code: string;
  normalized_type: NormalizedShiftType;
  is_split_shift: boolean;
  split_segments?: SplitSegment[];
  confidence: number;
  is_ambiguous: boolean;
  start?: string;
  end?: string;
  notes?: string;
  patched?: boolean;
  previous_code?: string;
}

export interface RotaMetadata {
  detected_month: number;
  detected_year: number;
  staff_name: string;
  staff_id?: string;
  ward_unit?: string;
  total_days: number;
  source_filename?: string;
  extracted_at?: string;
  redacted_colleagues?: number;
}

export interface RotaExtractionResult {
  metadata: RotaMetadata;
  schedule: ScheduleCell[];
}

export interface ValidationIssue {
  day: number;
  kind: "dow_mismatch" | "missing_day" | "extra_day" | "low_confidence" | "lookalike" | "boundary";
  message: string;
  expected?: string;
  actual?: string;
  auto_rectified: boolean;
}

export interface ValidationResult {
  ok: boolean;
  issues: ValidationIssue[];
  rectified: RotaExtractionResult;
  table_shift_detected: boolean;
}

export interface NurseProfile {
  userId: string;
  name: string;
  staffId: string;
  ward: string;
  hospital: string;
  timezone: string;
  identityTokens: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PrivacySettings {
  ephemeralProcessing: boolean;
  redactColleagues: boolean;
  omitLeavesFromCalendar: boolean;
  includeAlarms: boolean;
  alarmMinutes: number;
}

export interface RotaDocument {
  id: string;
  month: number;
  year: number;
  extraction: RotaExtractionResult;
  sequence: number;
  sourceKind: "image" | "pdf" | "text" | "demo" | "manual";
  sourceName: string;
  documentDataUrl?: string;
  createdAt: string;
  updatedAt: string;
  webcalToken: string;
}

export interface PipelineStage {
  id: string;
  label: string;
  detail: string;
  status: "pending" | "running" | "done" | "warn" | "error";
}

export type EngineMode = "autopilot" | "inspector";

export interface AnalyticsSnapshot {
  totalDutyHours: number;
  nightShiftCount: number;
  consecutiveDaysMax: number;
  weekendCoverage: number;
  restPeriodHealth: number;
  leaveDays: number;
  offDays: number;
  workDays: number;
  splitDays: number;
  hoursByType: Record<string, number>;
  weeklyHours: number[];
}

export interface SwapSlot {
  day: number;
  date: string;
  selfCode: string;
  peerCode: string;
  kind: "take" | "give" | "mutual";
  reason: string;
}

export interface SwapPayload {
  hash: string;
  profile: Pick<NurseProfile, "name" | "staffId" | "ward">;
  month: number;
  year: number;
  schedule: Array<{ day: number; raw_code: string; normalized_type: NormalizedShiftType }>;
  createdAt: string;
}

export interface FeedRecord {
  token: string;
  userId: string;
  ics: string;
  extraction: RotaExtractionResult;
  sequence: number;
  updatedAt: string;
}

export interface ImageProcessResult {
  dataUrl: string;
  width: number;
  height: number;
  binarized: boolean;
  dewarped: boolean;
}

export const CONFIDENCE_THRESHOLD = 0.92;

export const LOOKALIKE_PAIRS: Array<[string, string]> = [
  ["CL", "EL"],
  ["D", "O"],
  ["D", "0"],
  ["8", "B"],
  ["S", "5"],
  ["M", "N"],
  ["SL", "EL"],
  ["GH", "CH"],
];
