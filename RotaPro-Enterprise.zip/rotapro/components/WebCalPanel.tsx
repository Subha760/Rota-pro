"use client";

import { useState } from "react";
import { Check, Copy, Radio } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { copyText } from "@/lib/utils";

export function WebCalPanel() {
  const { webcalUrl, webcalHttpUrl, document, extraction } = useRota();
  const [copied, setCopied] = useState(false);
  if (!extraction) return null;

  return (
    <div className="rounded-3xl border border-white/10 bg-navy-900/70 p-4">
      <div className="flex items-center gap-2 text-teal-300">
        <Radio className="h-4 w-4" />
        <h3 className="font-display text-sm text-white">Live WebCal feed</h3>
      </div>
      <p className="mt-1 text-[11px] text-slate-500">
        Subscribe once. Re-uploads increment SEQUENCE {document?.sequence ?? 1} so Google, Apple, and
        Outlook overwrite — they never duplicate.
      </p>
      <div className="mt-3 flex items-center gap-2 rounded-xl bg-navy-950/70 ring-1 ring-white/10 px-3 py-2">
        <code className="flex-1 truncate text-[11px] text-cyan-200">{webcalUrl}</code>
        <button
          type="button"
          className="icon-btn"
          onClick={async () => {
            await copyText(webcalUrl);
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }}
        >
          {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
        </button>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <a href={webcalUrl} className="btn-primary !h-8 !text-xs">
          Subscribe
        </a>
        <a href={webcalHttpUrl} target="_blank" rel="noreferrer" className="btn-ghost !h-8 !text-xs">
          Open HTTP .ics
        </a>
      </div>
    </div>
  );
}
