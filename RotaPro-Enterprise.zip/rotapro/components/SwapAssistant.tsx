"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeftRight, Check, Copy, X } from "lucide-react";
import { nanoid } from "nanoid";
import { useRota } from "@/context/RotaContext";
import { buildSwapPayload, decodeSwap, encodeSwap, findSwapSlots } from "@/lib/swap";
import { copyText } from "@/lib/utils";
import type { SwapPayload } from "@/types/rota";

export function SwapAssistant({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { extraction, profile } = useRota();
  const [peerRaw, setPeerRaw] = useState("");
  const [copied, setCopied] = useState(false);
  const [hash, setHash] = useState<string | null>(null);

  const selfPayload = useMemo(() => {
    if (!extraction) return null;
    return buildSwapPayload("local", {
      ...extraction,
      metadata: { ...extraction.metadata, staff_name: profile.name || extraction.metadata.staff_name },
    });
  }, [extraction, profile.name]);

  const shareUrl = hash && typeof window !== "undefined" ? `${window.location.origin}/swap/${hash}` : "";

  const publish = async () => {
    if (!selfPayload) return;
    const id = nanoid(14);
    const payload: SwapPayload = { ...selfPayload, hash: id };
    await fetch("/api/swap", { method: "POST", body: JSON.stringify(payload) });
    setHash(id);
    await copyText(`${window.location.origin}/swap/${id}#${encodeSwap(payload)}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const peer: SwapPayload | null = useMemo(() => {
    const t = peerRaw.trim();
    if (!t) return null;
    const maybeHash = t.split("/").pop()?.split("#")[1] || t;
    return decodeSwap(maybeHash);
  }, [peerRaw]);

  const slots = selfPayload && peer ? findSwapSlots(selfPayload, peer) : [];

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            initial={{ y: 16, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 16, opacity: 0 }}
            className="w-full max-w-2xl rounded-3xl border border-white/10 bg-navy-950 p-6"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.2em] text-teal-300">Peer-to-peer</p>
                <h2 className="font-display text-xl text-white flex items-center gap-2">
                  <ArrowLeftRight className="h-5 w-5 text-teal-300" />
                  Shift swap assistant
                </h2>
              </div>
              <button type="button" className="icon-btn" onClick={onClose}>
                <X className="h-4 w-4" />
              </button>
            </div>

            {!extraction ? (
              <p className="mt-6 text-sm text-slate-400">Load a rota first, then generate an obfuscated swap link.</p>
            ) : (
              <>
                <p className="mt-3 text-sm text-slate-400">
                  Share an obfuscated roster link. We highlight conflict-free slots — you OFF while they work, or
                  vice versa.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button type="button" className="btn-primary" onClick={() => void publish()}>
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    Generate swap link
                  </button>
                  {shareUrl && <code className="text-[11px] text-cyan-200 truncate max-w-[280px]">{shareUrl}</code>}
                </div>
                <label className="mt-5 block text-xs text-slate-400">
                  Paste peer link or payload
                  <input
                    value={peerRaw}
                    onChange={(e) => setPeerRaw(e.target.value)}
                    className="mt-1 w-full rounded-xl bg-white/5 px-3 py-2 text-sm text-white ring-1 ring-white/10"
                    placeholder="rotapro.app/swap/… or encoded payload"
                  />
                </label>
                {peer && (
                  <div className="mt-4 max-h-64 overflow-auto rounded-2xl border border-white/10">
                    <table className="w-full text-sm">
                      <thead className="text-[11px] uppercase tracking-wider text-slate-500">
                        <tr>
                          <th className="px-3 py-2 text-left">Day</th>
                          <th className="px-3 py-2 text-left">You</th>
                          <th className="px-3 py-2 text-left">{peer.profile.name || "Peer"}</th>
                          <th className="px-3 py-2 text-left">Kind</th>
                        </tr>
                      </thead>
                      <tbody>
                        {slots.map((s) => (
                          <tr key={s.day} className="border-t border-white/5">
                            <td className="px-3 py-2 text-slate-300">{s.day}</td>
                            <td className="px-3 py-2 text-teal-200">{s.selfCode}</td>
                            <td className="px-3 py-2 text-cyan-200">{s.peerCode}</td>
                            <td className="px-3 py-2">
                              <span
                                className={`rounded-full px-2 py-0.5 text-[11px] ${
                                  s.kind === "take"
                                    ? "bg-emerald-400/15 text-emerald-300"
                                    : s.kind === "give"
                                    ? "bg-amber-400/15 text-amber-300"
                                    : "bg-sky-400/15 text-sky-300"
                                }`}
                              >
                                {s.kind}
                              </span>
                            </td>
                          </tr>
                        ))}
                        {slots.length === 0 && (
                          <tr>
                            <td colSpan={4} className="px-3 py-6 text-center text-slate-500">
                              No conflict-free slots this month.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
