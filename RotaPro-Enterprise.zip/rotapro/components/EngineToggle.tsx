"use client";

import { motion } from "framer-motion";
import { Bot, ScanSearch } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { cn } from "@/lib/utils";

export function EngineToggle() {
  const { engine, setEngine } = useRota();
  return (
    <div className="relative grid grid-cols-2 rounded-full bg-white/5 p-1 ring-1 ring-white/10">
      <motion.div
        layout
        className="absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-full bg-teal-400/20 ring-1 ring-teal-300/40"
        style={{ left: engine === "autopilot" ? 4 : "calc(50% + 0px)" }}
        transition={{ type: "spring", stiffness: 380, damping: 30 }}
      />
      <button
        type="button"
        onClick={() => void setEngine("autopilot")}
        className={cn(
          "relative z-10 flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium",
          engine === "autopilot" ? "text-teal-100" : "text-slate-400"
        )}
      >
        <Bot className="h-3.5 w-3.5" />
        Autopilot
      </button>
      <button
        type="button"
        onClick={() => void setEngine("inspector")}
        className={cn(
          "relative z-10 flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium",
          engine === "inspector" ? "text-teal-100" : "text-slate-400"
        )}
      >
        <ScanSearch className="h-3.5 w-3.5" />
        Inspector
      </button>
    </div>
  );
}
