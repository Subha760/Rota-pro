"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, Sparkles } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { QuickPalette } from "@/components/QuickPalette";
import { lookupShift, shiftByType } from "@/lib/shift-definitions";
import { DOW } from "@/lib/date-validator";
import { cn } from "@/lib/utils";
import type { ScheduleCell } from "@/types/rota";

const WEEK = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;

export function CalendarGrid() {
  const { extraction, month, year, updateCell, processing } = useRota();
  const [active, setActive] = useState<ScheduleCell | null>(null);

  const weeks = useMemo(() => {
    if (!extraction) return [];
    const byDay = new Map(extraction.schedule.map((c) => [c.day, c]));
    const first = new Date(year, month - 1, 1);
    const js = first.getDay(); // 0 Sun
    const mondayIndex = (js + 6) % 7;
    const total = extraction.metadata.total_days;
    const cells: Array<ScheduleCell | null> = [];
    for (let i = 0; i < mondayIndex; i++) cells.push(null);
    for (let d = 1; d <= total; d++) cells.push(byDay.get(d) ?? null);
    while (cells.length % 7) cells.push(null);
    const rows: Array<Array<ScheduleCell | null>> = [];
    for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
    return rows;
  }, [extraction, month, year]);

  if (!extraction) return null;

  return (
    <div className="rounded-3xl border border-white/10 bg-navy-900/70 p-3 sm:p-5 backdrop-blur">
      <div className="mb-3 grid grid-cols-7 gap-1.5">
        {WEEK.map((d) => (
          <div
            key={d}
            className="text-center text-[10px] sm:text-xs uppercase tracking-[0.18em] text-slate-500 py-1"
          >
            {d}
          </div>
        ))}
      </div>
      <div className="grid gap-1.5">
        {weeks.map((row, ri) => (
          <div key={ri} className="grid grid-cols-7 gap-1.5">
            {row.map((cell, ci) => {
              if (!cell) {
                return <div key={`e-${ri}-${ci}`} className="min-h-[72px] rounded-2xl bg-white/[0.02]" />;
              }
              const def = lookupShift(cell.raw_code) ?? shiftByType(cell.normalized_type);
              const weekend = cell.day_of_week === "Sat" || cell.day_of_week === "Sun";
              return (
                <motion.button
                  key={cell.day}
                  type="button"
                  layout
                  disabled={processing}
                  onClick={() => setActive(cell)}
                  whileHover={{ y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  className={cn(
                    "relative min-h-[72px] sm:min-h-[86px] rounded-2xl border p-2 text-left transition",
                    "hover:ring-1 hover:ring-teal-300/40",
                    cell.is_ambiguous && "ring-1 ring-amber-400/70 animate-pulse-slow",
                    cell.patched && "ring-1 ring-emerald-400/40"
                  )}
                  style={{
                    background: `linear-gradient(180deg, ${def.color}26, ${def.color}10)`,
                    borderColor: `${def.color}40`,
                    opacity: weekend && def.normalizedType === "OFF" ? 0.85 : 1,
                  }}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-[11px] font-medium text-slate-300">{cell.day}</span>
                    {cell.is_ambiguous ? (
                      <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                    ) : cell.patched ? (
                      <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
                    ) : null}
                  </div>
                  <div
                    className="mt-2 inline-flex rounded-md px-1.5 py-0.5 font-display text-[11px] sm:text-xs font-semibold tracking-wide"
                    style={{ background: `${def.color}33`, color: def.color }}
                  >
                    {cell.raw_code}
                  </div>
                  <div className="mt-1 hidden sm:block text-[10px] text-slate-400 truncate">
                    {def.isAllDay ? def.label.split(" / ")[0] : `${def.start}–${def.end}`}
                  </div>
                  {cell.previous_code && (
                    <div className="mt-0.5 text-[9px] text-emerald-300/80">was {cell.previous_code}</div>
                  )}
                </motion.button>
              );
            })}
          </div>
        ))}
      </div>
      <QuickPalette
        cell={active}
        year={year}
        month={month}
        onPick={(code) => {
          if (active) void updateCell(active.day, code);
        }}
        onClose={() => setActive(null)}
      />
      <p className="sr-only">{DOW.join(" ")}</p>
    </div>
  );
}
