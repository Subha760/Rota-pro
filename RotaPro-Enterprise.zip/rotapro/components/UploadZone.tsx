"use client";

import { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Camera, FileUp, ImageIcon, Loader2, Sparkles, Type } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { cn } from "@/lib/utils";

const ACCEPT = "image/png,image/jpeg,image/jpg,image/webp,application/pdf,text/plain,text/csv";

export function UploadZone({ compact = false }: { compact?: boolean }) {
  const { ingestFiles, ingestDemo, ingestText, processing } = useRota();
  const [hover, setHover] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [paste, setPaste] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);

  const onFiles = useCallback(
    (list: FileList | File[] | null) => {
      if (!list || processing) return;
      const files = Array.from(list);
      if (files.length) void ingestFiles(files);
    },
    [ingestFiles, processing]
  );

  return (
    <div className={cn("w-full", compact ? "" : "max-w-3xl mx-auto")}>
      <motion.div
        onDragOver={(e) => {
          e.preventDefault();
          setHover(true);
        }}
        onDragLeave={() => setHover(false)}
        onDrop={(e) => {
          e.preventDefault();
          setHover(false);
          onFiles(e.dataTransfer.files);
        }}
        animate={{
          borderColor: hover ? "rgba(45, 212, 191, 0.7)" : "rgba(45, 212, 191, 0.18)",
          background: hover ? "rgba(13, 28, 45, 0.9)" : "rgba(10, 18, 32, 0.72)",
        }}
        className={cn(
          "relative overflow-hidden rounded-3xl border border-dashed p-8 sm:p-12 text-center",
          "shadow-[0_0_80px_-24px_rgba(45,212,191,0.45)]",
          compact && "p-6 sm:p-8 rounded-2xl"
        )}
      >
        <div className="pointer-events-none absolute inset-0 opacity-40 bg-grid" />
        <div className="relative">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-400/10 ring-1 ring-teal-300/30">
            {processing ? (
              <Loader2 className="h-6 w-6 animate-spin text-teal-300" />
            ) : (
              <FileUp className="h-6 w-6 text-teal-300" />
            )}
          </div>
          <h2 className="font-display text-xl sm:text-2xl text-slate-50">
            Drop a duty rota — Autopilot takes it from here
          </h2>
          <p className="mt-2 text-sm text-slate-400 max-w-lg mx-auto">
            PNG, JPG, WebP, multi-page PDF or a pasted grid. We isolate your row, anchor Day 1, and
            live-sync WebCal with incremental SEQUENCE.
          </p>

          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              disabled={processing}
              onClick={() => inputRef.current?.click()}
              className="btn-primary"
            >
              <ImageIcon className="h-4 w-4" />
              Choose file
            </button>
            <button
              type="button"
              disabled={processing}
              onClick={() => camRef.current?.click()}
              className="btn-ghost"
            >
              <Camera className="h-4 w-4" />
              Camera snap
            </button>
            <button
              type="button"
              disabled={processing}
              onClick={() => setPasteOpen((v) => !v)}
              className="btn-ghost"
            >
              <Type className="h-4 w-4" />
              Paste grid
            </button>
            <button type="button" disabled={processing} onClick={() => void ingestDemo()} className="btn-ghost">
              <Sparkles className="h-4 w-4" />
              Load demo rota
            </button>
          </div>
          <p className="mt-4 text-[11px] uppercase tracking-[0.2em] text-slate-500">
            Zero PII leakage · colleague names redacted · RFC 5545
          </p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT}
          className="hidden"
          onChange={(e) => {
            onFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <input
          ref={camRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            onFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </motion.div>

      <AnimatePresence>
        {pasteOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4 rounded-2xl border border-white/10 bg-navy-800/80 p-4"
          >
            <textarea
              value={paste}
              onChange={(e) => setPaste(e.target.value)}
              placeholder="Priya Sharma  M  M  E  N  N  OFF  OFF  D  L  …"
              rows={4}
              className="w-full resize-y rounded-xl bg-navy-950/80 px-3 py-2 text-sm text-slate-200 outline-none ring-1 ring-white/10 focus:ring-teal-400/40"
            />
            <div className="mt-3 flex justify-end">
              <button
                type="button"
                className="btn-primary"
                disabled={!paste.trim() || processing}
                onClick={() => {
                  void ingestText(paste);
                  setPasteOpen(false);
                }}
              >
                Parse row
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
