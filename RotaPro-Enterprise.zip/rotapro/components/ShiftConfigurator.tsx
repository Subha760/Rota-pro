"use client";

import { useState } from "react";
import { nanoid } from "nanoid";
import { useRota } from "@/context/RotaContext";
import type { CustomShiftDefinition } from "@/types/rota";

/** Modal fragment for custom start/end hours, alarms, and split duties. */
export function ShiftConfigurator() {
  const { saveCustomShift, privacy } = useRota();
  const [code, setCode] = useState("OT");
  const [label, setLabel] = useState("Overtime");
  const [start, setStart] = useState("10:00");
  const [end, setEnd] = useState("18:00");
  const [split, setSplit] = useState(false);
  const [aStart, setAStart] = useState("08:00");
  const [aEnd, setAEnd] = useState("12:00");
  const [bStart, setBStart] = useState("16:00");
  const [bEnd, setBEnd] = useState("20:00");
  const [alarm, setAlarm] = useState(privacy.alarmMinutes);

  const save = () => {
    const def: CustomShiftDefinition = {
      id: nanoid(8),
      code,
      label,
      normalizedType: split ? "SPLIT" : "CUSTOM",
      start: split ? aStart : start,
      end: split ? bEnd : end,
      color: "#fbbf24",
      isOvernight: !split && end <= start,
      isAllDay: false,
      omitFromCalendar: false,
      alarmMinutes: alarm,
      splitSegments: split
        ? [
            { start: aStart, end: aEnd, title: "Block A" },
            { start: bStart, end: bEnd, title: "Block B" },
          ]
        : undefined,
    };
    void saveCustomShift(def);
  };

  return (
    <div className="space-y-3 rounded-2xl border border-white/10 p-4">
      <div className="grid grid-cols-2 gap-2">
        <Input label="Code" value={code} onChange={setCode} />
        <Input label="Label" value={label} onChange={setLabel} />
        {!split && (
          <>
            <Input label="Start" value={start} onChange={setStart} />
            <Input label="End" value={end} onChange={setEnd} />
          </>
        )}
        {split && (
          <>
            <Input label="A start" value={aStart} onChange={setAStart} />
            <Input label="A end" value={aEnd} onChange={setAEnd} />
            <Input label="B start" value={bStart} onChange={setBStart} />
            <Input label="B end" value={bEnd} onChange={setBEnd} />
          </>
        )}
        <Input label="Alarm (min)" value={String(alarm)} onChange={(v) => setAlarm(Number(v) || 0)} />
      </div>
      <label className="flex items-center gap-2 text-xs text-slate-400">
        <input type="checkbox" checked={split} onChange={(e) => setSplit(e.target.checked)} />
        Dual-interval split duty
      </label>
      <button type="button" className="btn-primary w-full" onClick={save}>
        Save duty definition
      </button>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="text-[11px] text-slate-400">
      {label}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl bg-white/5 px-3 py-2 text-sm text-white ring-1 ring-white/10"
      />
    </label>
  );
}
