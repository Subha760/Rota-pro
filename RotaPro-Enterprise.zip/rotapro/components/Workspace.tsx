"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Header } from "@/components/Header";
import { UploadZone } from "@/components/UploadZone";
import { CalendarGrid } from "@/components/CalendarGrid";
import { AnalyticsWidget } from "@/components/AnalyticsWidget";
import { DocumentViewer } from "@/components/DocumentViewer";
import { PipelineStatus } from "@/components/PipelineStatus";
import { WebCalPanel } from "@/components/WebCalPanel";
import { SettingsDrawer } from "@/components/SettingsDrawer";
import { SwapAssistant } from "@/components/SwapAssistant";
import { AmbiguousPrompt } from "@/components/AmbiguousPrompt";
import { useRota } from "@/context/RotaContext";

export function Workspace() {
  const { ready, extraction, engine, processing, profile, updateProfile } = useRota();
  const [settings, setSettings] = useState(false);
  const [swap, setSwap] = useState(false);
  const [onboardName, setOnboardName] = useState(profile.name);

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-teal-300/30 border-t-teal-300" />
      </div>
    );
  }

  const needsName = !profile.name;

  return (
    <div className="min-h-screen">
      <Header onOpenSettings={() => setSettings(true)} onOpenSwap={() => setSwap(true)} />
      <main className="mx-auto max-w-[1440px] px-4 py-6 sm:py-8">
        {!extraction && (
          <div className="mx-auto max-w-3xl text-center mb-10">
            <p className="text-[11px] uppercase tracking-[0.28em] text-teal-300/80">Hospital duty intelligence</p>
            <h1 className="mt-3 font-display text-4xl sm:text-5xl text-white leading-[1.1]">
              Rotas in. Verified calendars out.
              <span className="block text-teal-200/90">Zero date misalignment.</span>
            </h1>
            <p className="mt-4 text-slate-400 max-w-xl mx-auto">
              Convert scans, snaps, and PDFs into RFC 5545 .ics files and live WebCal subscriptions — with
              overnight rollover math, confidence badges, and peer-to-peer swap matching.
            </p>
          </div>
        )}

        <AnimatePresence>
          {needsName && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mx-auto mb-6 max-w-3xl rounded-2xl border border-teal-400/20 bg-teal-400/5 p-4 flex flex-col sm:flex-row gap-3 sm:items-end"
            >
              <label className="flex-1 text-xs text-slate-400">
                Staff name (used for row lock)
                <input
                  value={onboardName}
                  onChange={(e) => setOnboardName(e.target.value)}
                  placeholder="e.g. Priya Sharma"
                  className="mt-1 w-full rounded-xl bg-navy-950 px-3 py-2 text-sm text-white ring-1 ring-white/10"
                />
              </label>
              <button
                type="button"
                className="btn-primary"
                onClick={() => void updateProfile({ name: onboardName, identityTokens: [onboardName] })}
              >
                Remember me
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {!extraction || processing ? (
          <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr] items-start">
            <UploadZone />
            <PipelineStatus />
          </div>
        ) : engine === "inspector" ? (
          <div className="grid gap-4 xl:grid-cols-[1.05fr_0.95fr] items-start">
            <DocumentViewer />
            <div className="space-y-4">
              <UploadZone compact />
              <AmbiguousPrompt />
              <CalendarGrid />
            </div>
          </div>
        ) : (
          <div className="grid gap-6 xl:grid-cols-[1.35fr_0.65fr] items-start">
            <div className="space-y-4">
              <CalendarGrid />
              <UploadZone compact />
            </div>
            <div className="space-y-4 xl:sticky xl:top-20">
              <PipelineStatus />
              <AmbiguousPrompt />
              <WebCalPanel />
              <AnalyticsWidget />
            </div>
          </div>
        )}

        {extraction && engine === "inspector" && (
          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <WebCalPanel />
            <AnalyticsWidget />
          </div>
        )}
      </main>
      <SettingsDrawer open={settings} onClose={() => setSettings(false)} />
      <SwapAssistant open={swap} onClose={() => setSwap(false)} />
    </div>
  );
}
