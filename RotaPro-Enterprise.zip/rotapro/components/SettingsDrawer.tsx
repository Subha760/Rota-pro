"use client";

import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { SHIFT_DICTIONARY } from "@/lib/shift-definitions";
import { useState } from "react";
import type { CustomShiftDefinition } from "@/types/rota";
import { nanoid } from "nanoid";

export function SettingsDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { profile, updateProfile, privacy, updatePrivacy, saveCustomShift } = useRota();
  const [customCode, setCustomCode] = useState("OT");
  const [customLabel, setCustomLabel] = useState("Overtime");
  const [customStart, setCustomStart] = useState("10:00");
  const [customEnd, setCustomEnd] = useState("18:00");

  const addCustom = () => {
    const def: CustomShiftDefinition = {
      id: nanoid(8),
      code: customCode,
      label: customLabel,
      normalizedType: "CUSTOM",
      start: customStart,
      end: customEnd,
      color: "#fbbf24",
      isOvernight: customEnd <= customStart,
      isAllDay: false,
      omitFromCalendar: false,
      alarmMinutes: 90,
    };
    void saveCustomShift(def);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex justify-end bg-black/50" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <button className="flex-1" aria-label="Close settings" onClick={onClose} />
          <motion.aside
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 40, opacity: 0 }}
            className="h-full w-full max-w-md overflow-y-auto border-l border-white/10 bg-navy-950 p-6"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg text-white">Identity & compliance</h2>
              <button type="button" className="icon-btn" onClick={onClose}>
                <X className="h-4 w-4" />
              </button>
            </div>

            <section className="mt-6 space-y-3">
              <Field label="Full name" value={profile.name} onChange={(v) => updateProfile({ name: v, identityTokens: [v, profile.staffId, profile.ward].filter(Boolean) })} />
              <Field label="Staff ID" value={profile.staffId} onChange={(v) => updateProfile({ staffId: v })} />
              <Field label="Ward / unit" value={profile.ward} onChange={(v) => updateProfile({ ward: v })} />
              <Field label="Hospital" value={profile.hospital} onChange={(v) => updateProfile({ hospital: v })} />
              <Field label="Timezone" value={profile.timezone} onChange={(v) => updateProfile({ timezone: v })} />
            </section>

            <section className="mt-8">
              <h3 className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Privacy</h3>
              <Toggle
                label="Redact colleague names"
                hint="Scrub other staff before storage or .ics serialisation"
                checked={privacy.redactColleagues}
                onChange={(v) => updatePrivacy({ redactColleagues: v })}
              />
              <Toggle
                label="Ephemeral processing"
                hint="RAM-only images — wipe scans after parse"
                checked={privacy.ephemeralProcessing}
                onChange={(v) => updatePrivacy({ ephemeralProcessing: v })}
              />
              <Toggle
                label="Omit leaves from calendar"
                hint="Keep OFF / CL / SL / EL / GH out of the .ics"
                checked={privacy.omitLeavesFromCalendar}
                onChange={(v) => updatePrivacy({ omitLeavesFromCalendar: v })}
              />
              <Toggle
                label="VALARM reminders"
                hint={`Default ${privacy.alarmMinutes} minutes before shift start`}
                checked={privacy.includeAlarms}
                onChange={(v) => updatePrivacy({ includeAlarms: v })}
              />
              <label className="mt-3 block text-xs text-slate-400">
                Alarm lead (minutes)
                <input
                  type="number"
                  min={0}
                  max={720}
                  value={privacy.alarmMinutes}
                  onChange={(e) => updatePrivacy({ alarmMinutes: Number(e.target.value) })}
                  className="mt-1 w-full rounded-xl bg-white/5 px-3 py-2 text-sm text-white ring-1 ring-white/10"
                />
              </label>
            </section>

            <section className="mt-8">
              <h3 className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Duty dictionary</h3>
              <div className="mt-3 space-y-1.5">
                {SHIFT_DICTIONARY.map((s) => (
                  <div key={s.code} className="flex items-center justify-between rounded-xl bg-white/[0.03] px-3 py-2 text-xs">
                    <span className="font-semibold" style={{ color: s.color }}>
                      {s.code}
                    </span>
                    <span className="text-slate-400 truncate mx-3 flex-1">{s.label}</span>
                    <span className="text-slate-500 tabular-nums">
                      {s.isAllDay ? "ALL-DAY" : `${s.start}–${s.end}`}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            <section className="mt-8">
              <h3 className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Custom shift</h3>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Field label="Code" value={customCode} onChange={setCustomCode} />
                <Field label="Label" value={customLabel} onChange={setCustomLabel} />
                <Field label="Start" value={customStart} onChange={setCustomStart} />
                <Field label="End" value={customEnd} onChange={setCustomEnd} />
              </div>
              <button type="button" className="btn-primary mt-3 w-full" onClick={addCustom}>
                Save custom duty
              </button>
            </section>
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block text-xs text-slate-400">
      {label}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl bg-white/5 px-3 py-2 text-sm text-white ring-1 ring-white/10 focus:outline-none focus:ring-teal-400/40"
      />
    </label>
  );
}

function Toggle({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="mt-3 flex w-full items-start justify-between gap-3 rounded-2xl bg-white/[0.03] px-3 py-3 text-left"
    >
      <span>
        <span className="block text-sm text-slate-100">{label}</span>
        <span className="block text-[11px] text-slate-500">{hint}</span>
      </span>
      <span className={`mt-0.5 h-5 w-9 rounded-full p-0.5 ${checked ? "bg-teal-400/80" : "bg-white/10"}`}>
        <span className={`block h-4 w-4 rounded-full bg-white transition ${checked ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}
