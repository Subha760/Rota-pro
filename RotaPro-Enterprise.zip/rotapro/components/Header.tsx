"use client";

import { useEffect, useState } from "react";
import { CalendarDays, Download, Settings2, Share2, ShieldCheck } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { EngineToggle } from "@/components/EngineToggle";
import { monthName } from "@/lib/utils";

export function Header({
  onOpenSettings,
  onOpenSwap,
}: {
  onOpenSettings: () => void;
  onOpenSwap: () => void;
}) {
  const { month, year, setMonthYear, downloadIcs, extraction, document, profile } = useRota();
  const [install, setInstall] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstall(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const shiftMonth = (delta: number) => {
    const d = new Date(year, month - 1 + delta, 1);
    void setMonthYear(d.getMonth() + 1, d.getFullYear());
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-navy-950/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1440px] items-center gap-3 px-4 py-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative h-9 w-9 shrink-0 rounded-xl bg-gradient-to-br from-teal-300 to-cyan-600 shadow-[0_0_24px_rgba(45,212,191,0.45)]">
            <CalendarDays className="absolute inset-0 m-auto h-5 w-5 text-navy-950" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-[15px] leading-tight text-white tracking-wide">
              RotaPro <span className="text-teal-300">Enterprise</span>
            </div>
            <div className="text-[10px] uppercase tracking-[0.22em] text-slate-500">Rota2Cal · RFC 5545</div>
          </div>
        </div>

        <div className="ml-auto hidden md:block">
          <EngineToggle />
        </div>

        <div className="flex items-center rounded-full border border-white/10 bg-white/5 px-1">
          <button type="button" className="icon-btn" onClick={() => shiftMonth(-1)} aria-label="Previous month">
            ‹
          </button>
          <span className="px-2 text-sm text-slate-200 tabular-nums">
            {monthName(month)} {year}
          </span>
          <button type="button" className="icon-btn" onClick={() => shiftMonth(1)} aria-label="Next month">
            ›
          </button>
        </div>

        {extraction && (
          <button type="button" onClick={downloadIcs} className="btn-primary hidden sm:inline-flex">
            <Download className="h-4 w-4" />
            .ics
            {document ? <span className="opacity-70">SEQ {document.sequence}</span> : null}
          </button>
        )}

        <button type="button" onClick={onOpenSwap} className="icon-btn" title="Shift swap">
          <Share2 className="h-4 w-4" />
        </button>
        <button type="button" onClick={onOpenSettings} className="icon-btn" title="Settings">
          <Settings2 className="h-4 w-4" />
        </button>
        {install && (
          <button
            type="button"
            className="btn-ghost !px-3"
            onClick={async () => {
              await install.prompt();
              setInstall(null);
            }}
          >
            Install
          </button>
        )}
        <div className="hidden lg:flex items-center gap-2 rounded-full border border-white/10 px-3 py-1.5">
          <ShieldCheck className="h-3.5 w-3.5 text-teal-300" />
          <span className="text-xs text-slate-300 truncate max-w-[140px]">
            {profile.name || "Set profile"}
          </span>
        </div>
      </div>
      <div className="md:hidden px-4 pb-3">
        <EngineToggle />
      </div>
    </header>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
}
