"use client";

import { motion } from "framer-motion";
import { Activity, Clock3, HeartPulse, MoonStar, Palmtree, ShieldCheck } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { formatHours } from "@/lib/utils";
import { SHIFT_DICTIONARY } from "@/lib/shift-definitions";

export function AnalyticsWidget() {
  const { analytics, extraction } = useRota();
  if (!analytics || !extraction) return null;

  const healthColor =
    analytics.restPeriodHealth >= 75 ? "text-emerald-400" : analytics.restPeriodHealth >= 50 ? "text-amber-400" : "text-rose-400";

  const cards = [
    {
      label: "Duty hours",
      value: formatHours(analytics.totalDutyHours),
      hint: `${analytics.workDays} working days`,
      icon: Clock3,
    },
    {
      label: "Night shifts",
      value: String(analytics.nightShiftCount),
      hint: "20:30 → 08:00 rollovers",
      icon: MoonStar,
    },
    {
      label: "Longest streak",
      value: `${analytics.consecutiveDaysMax}d`,
      hint: "Consecutive days worked",
      icon: Activity,
    },
    {
      label: "Weekend cover",
      value: String(analytics.weekendCoverage),
      hint: "Sat/Sun duties",
      icon: ShieldCheck,
    },
    {
      label: "Rest health",
      value: `${analytics.restPeriodHealth}`,
      hint: "Index 0–100",
      icon: HeartPulse,
      valueClass: healthColor,
    },
    {
      label: "Leave + offs",
      value: `${analytics.leaveDays + analytics.offDays}`,
      hint: `${analytics.offDays} OFF · ${analytics.leaveDays} leave`,
      icon: Palmtree,
    },
  ];

  const maxWeek = Math.max(1, ...analytics.weeklyHours);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {cards.map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className="rounded-2xl border border-white/10 bg-navy-900/70 p-4"
          >
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-[11px] uppercase tracking-[0.16em]">{c.label}</span>
              <c.icon className="h-4 w-4 text-teal-300/80" />
            </div>
            <div className={`mt-2 font-display text-2xl text-white ${c.valueClass ?? ""}`}>{c.value}</div>
            <div className="text-[11px] text-slate-500 mt-1">{c.hint}</div>
          </motion.div>
        ))}
      </div>

      <div className="rounded-2xl border border-white/10 bg-navy-900/70 p-4">
        <div className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Weekly duty load</div>
        <div className="mt-3 flex items-end gap-2 h-24">
          {analytics.weeklyHours.map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(h / maxWeek) * 100}%` }}
                className="w-full rounded-md bg-gradient-to-t from-teal-700 to-cyan-300 min-h-[4px]"
              />
              <span className="text-[10px] text-slate-500">W{i + 1}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-navy-900/70 p-4">
        <div className="text-[11px] uppercase tracking-[0.16em] text-slate-400 mb-3">Hours by type</div>
        <div className="flex flex-wrap gap-2">
          {SHIFT_DICTIONARY.filter((s) => (analytics.hoursByType[s.normalizedType] ?? 0) > 0).map((s) => (
            <span
              key={s.code}
              className="rounded-full px-2.5 py-1 text-[11px] border"
              style={{ color: s.color, borderColor: `${s.color}55`, background: `${s.color}18` }}
            >
              {s.code} · {formatHours(analytics.hoursByType[s.normalizedType])}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
