"use client";

import { useMemo, useState } from "react";
import { useRota } from "@/context/RotaContext";
import { PALETTE_CODES, lookupShift } from "@/lib/shift-definitions";
import { isoDate } from "@/lib/utils";

export function AmbiguousPrompt() {
  const { extraction, month, year, updateCell } = useRota();
  const queue = useMemo(
    () => extraction?.schedule.filter((c) => c.is_ambiguous) ?? [],
    [extraction]
  );
  const [idx, setIdx] = useState(0);
  if (!queue.length || !extraction) return null;
  const cell = queue[Math.min(idx, queue.length - 1)];

  return (
    <div className="rounded-3xl border border-amber-400/30 bg-amber-400/5 p-4">
      <p className="text-[11px] uppercase tracking-[0.18em] text-amber-300">Zero-guess fallback</p>
      <p className="mt-1 text-sm text-slate-200">
        Confirm shift for {isoDate(year, month, cell.day)} — read as{" "}
        <span className="font-semibold text-amber-200">{cell.raw_code}</span> ({Math.round(cell.confidence * 100)}%
        confidence)
      </p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {PALETTE_CODES.map((code) => {
          const def = lookupShift(code)!;
          return (
            <button
              key={code}
              type="button"
              onClick={() => {
                void updateCell(cell.day, code);
                setIdx((i) => i + 1);
              }}
              className="rounded-lg px-2 py-1 text-[11px] font-semibold ring-1"
              style={{ color: def.color, background: `${def.color}22`, borderColor: `${def.color}55` }}
            >
              {code}
            </button>
          );
        })}
      </div>
      <p className="mt-2 text-[11px] text-slate-500">
        {Math.min(idx + 1, queue.length)} of {queue.length} flagged cells
      </p>
    </div>
  );
}
