"use client";

import { useRef, useState } from "react";
import { Crop, RotateCcw, RotateCw, ZoomIn, ZoomOut, Contrast, Sun } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { cn } from "@/lib/utils";

export function DocumentViewer() {
  const { sourceUrl, document, cropAndReparse, processing } = useRota();
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [contrast, setContrast] = useState(1.1);
  const [brightness, setBrightness] = useState(1);
  const [cropMode, setCropMode] = useState(false);
  const [box, setBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);

  if (!sourceUrl) {
    return (
      <div className="flex h-full min-h-[320px] items-center justify-center rounded-3xl border border-dashed border-white/10 bg-navy-900/40 p-6 text-center">
        <p className="text-sm text-slate-400 max-w-xs">
          {document?.sourceKind === "demo"
            ? "Demo rota has no source scan. Upload a photo or PDF to unlock the inspector canvas."
            : "No document in memory. Drop a scan to pan, zoom, filter, and isolate your row."}
        </p>
      </div>
    );
  }

  const isPdf = sourceUrl.startsWith("data:application/pdf") || document?.sourceKind === "pdf";

  const onPointer = (e: React.PointerEvent) => {
    if (!cropMode || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    if (e.type === "pointerdown") {
      start.current = { x, y };
      setBox({ x, y, w: 0, h: 0 });
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    } else if (e.type === "pointermove" && start.current) {
      setBox({
        x: Math.min(start.current.x, x),
        y: Math.min(start.current.y, y),
        w: Math.abs(x - start.current.x),
        h: Math.abs(y - start.current.y),
      });
    } else if (e.type === "pointerup") {
      start.current = null;
    }
  };

  const applyCrop = async () => {
    if (!box || box.w < 8 || box.h < 8 || !stageRef.current) return;
    const img = stageRef.current.querySelector("img");
    if (!img) return;
    const canvas = window.document.createElement("canvas");
    const scaleX = (img as HTMLImageElement).naturalWidth / img.clientWidth;
    const scaleY = (img as HTMLImageElement).naturalHeight / img.clientHeight;
    canvas.width = Math.max(1, Math.round(box.w * scaleX));
    canvas.height = Math.max(1, Math.round(box.h * scaleY));
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(
      img as HTMLImageElement,
      box.x * scaleX,
      box.y * scaleY,
      box.w * scaleX,
      box.h * scaleY,
      0,
      0,
      canvas.width,
      canvas.height
    );
    const dataUrl = canvas.toDataURL("image/png");
    setCropMode(false);
    setBox(null);
    await cropAndReparse(dataUrl);
  };

  return (
    <div className="flex h-full flex-col rounded-3xl border border-white/10 bg-navy-900/70 overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-3 py-2">
        <Tool onClick={() => setZoom((z) => Math.min(3, z + 0.15))}>
          <ZoomIn className="h-4 w-4" />
        </Tool>
        <Tool onClick={() => setZoom((z) => Math.max(0.4, z - 0.15))}>
          <ZoomOut className="h-4 w-4" />
        </Tool>
        <Tool onClick={() => setRotation((r) => r - 90)}>
          <RotateCcw className="h-4 w-4" />
        </Tool>
        <Tool onClick={() => setRotation((r) => r + 90)}>
          <RotateCw className="h-4 w-4" />
        </Tool>
        <label className="flex items-center gap-1 text-[11px] text-slate-400 px-1">
          <Contrast className="h-3.5 w-3.5" />
          <input
            type="range"
            min={0.6}
            max={1.8}
            step={0.05}
            value={contrast}
            onChange={(e) => setContrast(parseFloat(e.target.value))}
          />
        </label>
        <label className="flex items-center gap-1 text-[11px] text-slate-400 px-1">
          <Sun className="h-3.5 w-3.5" />
          <input
            type="range"
            min={0.6}
            max={1.6}
            step={0.05}
            value={brightness}
            onChange={(e) => setBrightness(parseFloat(e.target.value))}
          />
        </label>
        <button
          type="button"
          onClick={() => {
            setCropMode((v) => !v);
            setBox(null);
          }}
          className={cn("icon-btn", cropMode && "bg-teal-400/20 text-teal-200")}
          title="Row isolator"
        >
          <Crop className="h-4 w-4" />
        </button>
        {cropMode && (
          <button type="button" disabled={processing} onClick={() => void applyCrop()} className="btn-primary !h-8 !text-xs">
            Lock row
          </button>
        )}
      </div>
      <div
        ref={stageRef}
        className={cn("relative flex-1 overflow-auto bg-navy-950/80", cropMode && "cursor-crosshair")}
        onPointerDown={onPointer}
        onPointerMove={onPointer}
        onPointerUp={onPointer}
      >
        <div className="flex min-h-full min-w-full items-start justify-center p-4">
          {isPdf && sourceUrl.startsWith("data:application/pdf") ? (
            <embed src={sourceUrl} type="application/pdf" className="h-[640px] w-full rounded-xl" />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={sourceUrl}
              alt="Duty rota scan"
              draggable={false}
              className="max-w-none origin-center rounded-md shadow-2xl select-none"
              style={{
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
                filter: `contrast(${contrast}) brightness(${brightness})`,
              }}
            />
          )}
        </div>
        {cropMode && box && (
          <div
            className="pointer-events-none absolute border-2 border-teal-300 bg-teal-300/10"
            style={{ left: box.x, top: box.y, width: box.w, height: box.h }}
          />
        )}
      </div>
    </div>
  );
}

function Tool({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="icon-btn">
      {children}
    </button>
  );
}
