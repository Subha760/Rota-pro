"use client";

import { Check, Loader2, AlertTriangle } from "lucide-react";
import { useRota } from "@/context/RotaContext";
import { cn } from "@/lib/utils";

export function PipelineStatus() {
  const { pipeline, processing, lastDiff, issues } = useRota();
  const started = pipeline.some((s) => s.status !== "pending");
  if (!started) return null;

  return (
    <div className="rounded-3xl border border-white/10 bg-navy-900/70 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-sm text-white">Zero-touch autopilot</h3>
        {lastDiff > 0 && (
          <span className="rounded-full bg-emerald-400/15 px-2 py-0.5 text-[11px] text-emerald-300">
            {lastDiff} auto-patched
          </span>
        )}
      </div>
      <ol className="space-y-2">
        {pipeline.map((s) => (
          <li key={s.id} className="flex items-start gap-3">
            <span
              className={cn(
                "mt-0.5 flex h-5 w-5 items-center justify-center rounded-full ring-1",
                s.status === "done" && "bg-teal-400/20 ring-teal-300/40 text-teal-200",
                s.status === "running" && "bg-cyan-400/15 ring-cyan-300/40 text-cyan-200",
                s.status === "warn" && "bg-amber-400/15 ring-amber-300/40 text-amber-200",
                s.status === "error" && "bg-rose-400/15 ring-rose-300/40 text-rose-200",
                s.status === "pending" && "bg-white/5 ring-white/10 text-slate-500"
              )}
            >
              {s.status === "running" ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : s.status === "warn" ? (
                <AlertTriangle className="h-3 w-3" />
              ) : s.status === "done" ? (
                <Check className="h-3 w-3" />
              ) : (
                <span className="h-1.5 w-1.5 rounded-full bg-current" />
              )}
            </span>
            <div className="min-w-0">
              <div className="text-sm text-slate-200">{s.label}</div>
              <div className="text-[11px] text-slate-500 truncate">{s.detail}</div>
            </div>
          </li>
        ))}
      </ol>
      {issues.length > 0 && !processing && (
        <p className="mt-3 text-[11px] text-amber-300/90">
          {issues.filter((i) => !i.auto_rectified).length} cells need confirmation ·{" "}
          {issues.filter((i) => i.auto_rectified).length} auto-rectified by calendar math
        </p>
      )}
    </div>
  );
}
