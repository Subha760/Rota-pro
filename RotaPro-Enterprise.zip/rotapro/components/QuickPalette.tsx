"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { PALETTE_CODES, lookupShift, badgeStyle } from "@/lib/shift-definitions";
import { isoDate, monthName } from "@/lib/utils";
import type { ScheduleCell } from "@/types/rota";

interface Props {
  cell: ScheduleCell | null;
  year: number;
  month: number;
  onPick: (code: string) => void;
  onClose: () => void;
}

export function QuickPalette({ cell, year, month, onPick, onClose }: Props) {
  useEffect(() => {
    if (!cell) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cell, onClose]);

  return (
    <AnimatePresence>
      {cell && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-sm p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 24, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 16, opacity: 0, scale: 0.96 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-3xl border border-white/10 bg-navy-900 p-5 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.2em] text-teal-300/80">1-tap palette</p>
                <h3 className="mt-1 font-display text-lg text-white">
                  {cell.day_of_week} {cell.day} {monthName(month)} {year}
                </h3>
                <p className="text-xs text-slate-400">
                  {isoDate(year, month, cell.day)} · current {cell.raw_code}
                  {cell.is_ambiguous ? " · needs confirm" : ""}
                </p>
              </div>
              <button type="button" onClick={onClose} className="icon-btn">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-5 grid grid-cols-4 gap-2">
              {PALETTE_CODES.map((code) => {
                const def = lookupShift(code)!;
                const style = badgeStyle(def.color);
                const active = cell.raw_code === code || cell.raw_code === def.code;
                return (
                  <button
                    key={code}
                    type="button"
                    onClick={() => {
                      onPick(code);
                      onClose();
                    }}
                    className="group rounded-2xl border px-2 py-3 text-center transition hover:scale-[1.03]"
                    style={{
                      background: active ? `${def.color}33` : style.background,
                      borderColor: active ? def.color : style.border,
                    }}
                  >
                    <div className="font-display text-base font-semibold" style={{ color: def.color }}>
                      {code}
                    </div>
                    <div className="mt-1 text-[10px] leading-tight text-slate-400">{def.label.split(" / ")[0]}</div>
                  </button>
                );
              })}
            </div>
            <p className="mt-4 text-[11px] text-slate-500">
              Confirm shift for {isoDate(year, month, cell.day)}: M · E · N · D · L · SPL · OFF · GH · CL · SL · EL · C/O
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
