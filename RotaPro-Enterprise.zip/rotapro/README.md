# RotaPro Enterprise (Rota2Cal)

Progressive Web App that turns hospital duty rotas — scans, mobile snaps, and PDFs — into verified **RFC 5545** `.ics` calendars, live **WebCal** subscriptions, and peer-to-peer shift-swap agreements with **zero date misalignment**.

Built for ward basements, lifts, and night duty: offline-first, IndexedDB-backed, colleague-redacting. **No API keys. No third-party AI calls.** Parsing, calendar math, and `.ics` generation all run locally.

## Dual engines

| Engine | Behaviour |
| --- | --- |
| **A · Zero-Touch Autopilot** | Drop-and-go ingest → contrast binarization → staff-row lock → Day-1 date anchor → smart diff / SEQUENCE patch → live WebCal |
| **B · Pro Inspector** | Dual-pane workspace: pan/zoom/filter document + heatmap calendar, bounding-box row isolator, 1-tap shift palette |

## Shift taxonomy

Timed duties with overnight rollover (`DTEND` on Day N+1 for nights):

- **M / MR / MO** 07:00–15:00 · **E / EV / AF** 13:00–21:00 · **N / NS / NT** 20:30–08:00
- **D / GEN** 08:30–17:00 · **L / LD** 07:30–20:30 · **SPL** 08:00–12:00 & 16:00–20:00 · **OC** on-call

Leaves (all-day, optionally omitted): **OFF / WO / RD**, **GH / PH**, **CL**, **SL / ML**, **EL / PL / AL**, **C/O**, **MAT / CCL**, **OD / TRG**.

Ambiguous cells (`CL` vs `EL`, `D` vs `O`, confidence &lt; 0.92) are amber-flagged and confirmed in a non-blocking micro-prompt.

## Calendar contract

```
UID: rota-[userId]-[year]-[month]-[day]@rotapro.app
SEQUENCE: n   ← increments on every re-upload / cell override
```

Google Calendar, Apple Calendar, and Outlook overwrite in place instead of duplicating.

Live feed:

```
webcal://<host>/api/webcal/<token>
```

## Stack

Next.js 14 App Router · TypeScript · Tailwind CSS · Framer Motion · Lucide · IndexedDB (`idb`) · on-device RFC 5545 serializer · local text-grid parser

## Quick start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Click **Load demo rota**, paste a grid, or drop a scan.

```bash
npm run build
npm start
```

No environment variables are required.

## Project map

```
types/rota.ts                 Extraction schema, profiles, analytics
lib/shift-definitions.ts      Duty dictionary, aliases, colours
lib/date-validator.ts         Day-1 anchor + DOW cross-check
lib/ics-generator.ts          RFC 5545 + VALARM + overnight math
lib/storage.ts                IndexedDB persistence
lib/ocr-engine.ts             Text-grid parser + local engine
app/api/ocr/parse/route.ts    Local parser (no external APIs)
app/api/webcal/[token]        Live WebCal GET + PUT
components/UploadZone.tsx
components/CalendarGrid.tsx
components/QuickPalette.tsx
components/AnalyticsWidget.tsx
app/page.tsx                  Dual-engine workspace
```

## Privacy

- Only the authenticated nurse's row is stored.
- Colleague names, signatures, and patient data are redacted before `.ics` serialisation.
- Ephemeral mode keeps scans in RAM and wipes `documentDataUrl` after parse.
- Uploads never leave this host — there is no cloud vision provider.

## PWA

`public/manifest.json` + `public/sw.js` cache the app shell. Install from the header when the browser fires `beforeinstallprompt`. IndexedDB keeps rotas available offline; WebCal sync retries on reconnect.

## License

Proprietary — RotaPro Enterprise. Internal hospital use.
