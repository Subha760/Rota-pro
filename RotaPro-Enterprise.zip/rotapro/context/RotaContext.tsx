"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { nanoid } from "nanoid";
import type {
  AnalyticsSnapshot,
  CustomShiftDefinition,
  EngineMode,
  NurseProfile,
  PipelineStage,
  PrivacySettings,
  RotaDocument,
  RotaExtractionResult,
  ScheduleCell,
  ValidationIssue,
} from "@/types/rota";
import {
  createDefaultProfile,
  DEFAULT_PRIVACY,
  getProfile,
  getRotaForMonth,
  getSettings,
  nextSequence,
  saveProfile,
  saveRota,
  saveSettings,
  wipeDocuments,
} from "@/lib/storage";
import { validateAndRectify } from "@/lib/date-validator";
import { computeAnalytics, diffSchedules } from "@/lib/analytics";
import { generateIcs, icsFilename } from "@/lib/ics-generator";
import { lookupShift, shiftByType } from "@/lib/shift-definitions";
import { downloadBlob, fileToDataUrl, sleep } from "@/lib/utils";
import { preprocessImage } from "@/lib/image-processor";
import { generateRealisticRota, parseTextRota } from "@/lib/ocr-engine";

const STAGES: Array<Pick<PipelineStage, "id" | "label" | "detail">> = [
  { id: "ingest", label: "Drop-and-Go Ingestion", detail: "Accept PNG, JPG, WebP, PDF" },
  { id: "preprocess", label: "Vision Preprocess", detail: "Contrast binarization · dewarp" },
  { id: "identity", label: "Auto-Identity & Row Lock", detail: "Isolate authenticated staff row" },
  { id: "dates", label: "Strict Date Anchor", detail: "Day 1 → last day · DOW audit" },
  { id: "diff", label: "Smart Diff & Auto-Patch", detail: "SEQUENCE increment · no duplicates" },
  { id: "sync", label: "Instant Live Sync", detail: "WebCal feed · RFC 5545 .ics" },
];

interface RotaContextValue {
  ready: boolean;
  profile: NurseProfile;
  privacy: PrivacySettings;
  customShifts: CustomShiftDefinition[];
  engine: EngineMode;
  webcalToken: string;
  document: RotaDocument | null;
  extraction: RotaExtractionResult | null;
  sourceUrl: string | null;
  pipeline: PipelineStage[];
  processing: boolean;
  issues: ValidationIssue[];
  analytics: AnalyticsSnapshot | null;
  lastDiff: number;
  month: number;
  year: number;
  setEngine: (m: EngineMode) => void;
  setMonthYear: (month: number, year: number) => void;
  updateProfile: (p: Partial<NurseProfile>) => Promise<void>;
  updatePrivacy: (p: Partial<PrivacySettings>) => Promise<void>;
  saveCustomShift: (s: CustomShiftDefinition) => Promise<void>;
  ingestFiles: (files: File[]) => Promise<void>;
  ingestDemo: () => Promise<void>;
  ingestText: (text: string) => Promise<void>;
  updateCell: (day: number, code: string) => Promise<void>;
  downloadIcs: () => void;
  webcalHttpUrl: string;
  webcalUrl: string;
  cropAndReparse: (dataUrl: string) => Promise<void>;
}

const RotaContext = createContext<RotaContextValue | null>(null);

export function useRota() {
  const ctx = useContext(RotaContext);
  if (!ctx) throw new Error("useRota must be used within RotaProvider");
  return ctx;
}

function idlePipeline(): PipelineStage[] {
  return STAGES.map((s) => ({ ...s, status: "pending" as const }));
}

export function RotaProvider({ children }: { children: ReactNode }) {
  const now = new Date();
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<NurseProfile>(createDefaultProfile());
  const [privacy, setPrivacy] = useState<PrivacySettings>(DEFAULT_PRIVACY);
  const [customShifts, setCustomShifts] = useState<CustomShiftDefinition[]>([]);
  const [engine, setEngineState] = useState<EngineMode>("autopilot");
  const [webcalToken, setWebcalToken] = useState("");
  const [document, setDocument] = useState<RotaDocument | null>(null);
  const [sourceUrl, setSourceUrl] = useState<string | null>(null);
  const [pipeline, setPipeline] = useState<PipelineStage[]>(idlePipeline);
  const [processing, setProcessing] = useState(false);
  const [issues, setIssues] = useState<ValidationIssue[]>([]);
  const [lastDiff, setLastDiff] = useState(0);
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());

  const extraction = document?.extraction ?? null;
  const analytics = useMemo(() => (extraction ? computeAnalytics(extraction) : null), [extraction]);

  const origin = typeof window !== "undefined" ? window.location.origin : "https://rotapro.app";
  const webcalHttpUrl = `${origin}/api/webcal/${webcalToken}`;
  const webcalUrl = webcalHttpUrl.replace(/^https:/, "webcal:").replace(/^http:/, "webcal:");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [p, s] = await Promise.all([getProfile(), getSettings()]);
      if (cancelled) return;
      if (p) setProfile(p);
      else {
        const created = createDefaultProfile();
        await saveProfile(created);
        setProfile(created);
      }
      setPrivacy(s.privacy);
      setCustomShifts(s.customShifts);
      setEngineState(s.engine);
      setWebcalToken(s.webcalToken);
      const existing = await getRotaForMonth(now.getFullYear(), now.getMonth() + 1);
      if (existing && !cancelled) {
        setDocument(existing);
        setSourceUrl(existing.documentDataUrl ?? null);
        setMonth(existing.month);
        setYear(existing.year);
      }
      setReady(true);
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setEngine = useCallback(async (m: EngineMode) => {
    setEngineState(m);
    await saveSettings({ engine: m });
  }, []);

  const setMonthYear = useCallback(async (m: number, y: number) => {
    setMonth(m);
    setYear(y);
    const existing = await getRotaForMonth(y, m);
    if (existing) {
      setDocument(existing);
      setSourceUrl(existing.documentDataUrl ?? null);
    } else {
      setDocument(null);
      setSourceUrl(null);
    }
  }, []);

  const updateProfile = useCallback(async (patch: Partial<NurseProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...patch, updatedAt: new Date().toISOString() };
      void saveProfile(next);
      return next;
    });
  }, []);

  const updatePrivacy = useCallback(async (patch: Partial<PrivacySettings>) => {
    setPrivacy((prev) => {
      const next = { ...prev, ...patch };
      void saveSettings({ privacy: next });
      return next;
    });
  }, []);

  const saveCustomShift = useCallback(async (s: CustomShiftDefinition) => {
    setCustomShifts((prev) => {
      const next = [...prev.filter((x) => x.id !== s.id), s];
      void saveSettings({ customShifts: next });
      return next;
    });
  }, []);

  const mark = useCallback((id: string, status: PipelineStage["status"], detail?: string) => {
    setPipeline((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status, detail: detail ?? s.detail } : s))
    );
  }, []);

  const persistAndSync = useCallback(
    async (opts: {
      extraction: RotaExtractionResult;
      sourceKind: RotaDocument["sourceKind"];
      sourceName: string;
      dataUrl?: string;
      previous?: RotaDocument | null;
    }) => {
      const { extraction: raw } = opts;
      mark("dates", "running");
      const validated = validateAndRectify(raw);
      setIssues(validated.issues);
      mark(
        "dates",
        validated.table_shift_detected ? "warn" : "done",
        validated.table_shift_detected
          ? "Table shift detected and rectified"
          : `Anchored 1–${validated.rectified.metadata.total_days}`
      );

      mark("diff", "running");
      const prevDoc =
        opts.previous ??
        (await getRotaForMonth(
          validated.rectified.metadata.detected_year,
          validated.rectified.metadata.detected_month
        ));
      const diff = diffSchedules(prevDoc?.extraction ?? null, validated.rectified);
      const sequence = prevDoc
        ? prevDoc.sequence + (diff.changed > 0 ? 1 : 0) || (await nextSequence(validated.rectified.metadata.detected_year, validated.rectified.metadata.detected_month))
        : 1;
      const patched: RotaExtractionResult = { ...validated.rectified, schedule: diff.cells };
      setLastDiff(diff.changed);
      mark(
        "diff",
        "done",
        diff.changed ? `${diff.changed} shift${diff.changed === 1 ? "" : "s"} patched · SEQUENCE ${sequence}` : `No drift · SEQUENCE ${sequence}`
      );

      const dataUrl = privacy.ephemeralProcessing ? undefined : opts.dataUrl;
      const doc: RotaDocument = {
        id: `${patched.metadata.detected_year}-${patched.metadata.detected_month}`,
        month: patched.metadata.detected_month,
        year: patched.metadata.detected_year,
        extraction: patched,
        sequence,
        sourceKind: opts.sourceKind,
        sourceName: opts.sourceName,
        documentDataUrl: dataUrl,
        createdAt: prevDoc?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        webcalToken,
      };
      await saveRota(doc);
      setDocument(doc);
      setMonth(doc.month);
      setYear(doc.year);
      if (privacy.ephemeralProcessing) {
        setSourceUrl(null);
        await wipeDocuments();
      } else if (opts.dataUrl) {
        setSourceUrl(opts.dataUrl);
      }

      mark("sync", "running");
      try {
        await fetch(`/api/webcal/${webcalToken}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            extraction: patched,
            profile,
            sequence,
            privacy,
          }),
        });
        mark("sync", "done", "WebCal feed live");
      } catch {
        mark("sync", "warn", "Feed cached locally · retry on reconnect");
      }
    },
    [mark, privacy, profile, webcalToken]
  );

  const runPipeline = useCallback(
    async (work: () => Promise<void>) => {
      setProcessing(true);
      setPipeline(idlePipeline());
      try {
        await work();
      } finally {
        setProcessing(false);
      }
    },
    []
  );

  const ingestFiles = useCallback(
    async (files: File[]) => {
      const file = files[0];
      if (!file) return;
      await runPipeline(async () => {
        mark("ingest", "running", file.name);
        await sleep(280);
        mark("ingest", "done", `${file.name} · ${(file.size / 1024).toFixed(0)} KB`);

        mark("preprocess", "running");
        let dataUrl = await fileToDataUrl(file);
        let textHint = "";
        if (file.type.startsWith("image/")) {
          try {
            const processed = await preprocessImage(file, { binarize: true, contrast: 1.3 });
            dataUrl = processed.dataUrl;
            mark("preprocess", "done", `${processed.width}×${processed.height} · Otsu binarized`);
          } catch {
            mark("preprocess", "warn", "Pass-through (canvas unavailable)");
          }
        } else if (file.type === "application/pdf") {
          mark("preprocess", "done", "Multi-page PDF staged for row lock");
        } else if (file.type.startsWith("text/") || file.name.endsWith(".csv")) {
          textHint = await file.text();
          mark("preprocess", "done", "Plain-text / CSV grid detected");
        } else {
          mark("preprocess", "done", "Binary accepted");
        }

        mark("identity", "running", "Matching staff ID / name / ward");
        const res = await fetch("/api/ocr/parse", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            filename: file.name,
            mime: file.type,
            dataUrl: file.type.startsWith("image/") ? dataUrl : undefined,
            textHint: textHint || undefined,
            profile,
            month,
            year,
            ephemeral: privacy.ephemeralProcessing,
          }),
        });
        const json = await res.json();
        if (!json.ok) throw new Error(json.error || "Parse failed");
        mark(
          "identity",
          "done",
          `Locked ${json.result.metadata.staff_name}${
            json.result.metadata.redacted_colleagues
              ? ` · ${json.result.metadata.redacted_colleagues} colleagues redacted`
              : ""
          }`
        );
        setIssues(json.validation?.issues ?? []);
        await persistAndSync({
          extraction: json.result,
          sourceKind: file.type === "application/pdf" ? "pdf" : file.type.startsWith("image/") ? "image" : "text",
          sourceName: file.name,
          dataUrl,
        });
      });
    },
    [mark, month, persistAndSync, privacy.ephemeralProcessing, profile, runPipeline, year]
  );

  const ingestDemo = useCallback(async () => {
    await runPipeline(async () => {
      mark("ingest", "running", "Demo ward roster");
      await sleep(200);
      mark("ingest", "done", "Synthetic multi-staff ward sheet");
      mark("preprocess", "running");
      await sleep(220);
      mark("preprocess", "done", "Dewarp · contrast stretch");
      mark("identity", "running");
      await sleep(240);
      const extraction = generateRealisticRota({
        year,
        month,
        profile,
        seed: `${profile.userId}-demo`,
        sourceName: "demo-ward-roster.png",
        injectAmbiguity: true,
      });
      mark("identity", "done", `Row lock on ${extraction.metadata.staff_name}`);
      await persistAndSync({
        extraction,
        sourceKind: "demo",
        sourceName: "demo-ward-roster.png",
      });
    });
  }, [mark, month, persistAndSync, profile, runPipeline, year]);

  const ingestText = useCallback(
    async (text: string) => {
      await runPipeline(async () => {
        mark("ingest", "done", "Pasted grid");
        mark("preprocess", "done", "Tokenised shift codes");
        mark("identity", "running");
        const parsed = parseTextRota(text, profile, year, month);
        if (!parsed) throw new Error("Could not detect a staff row of shift codes.");
        mark("identity", "done", `Locked ${parsed.metadata.staff_name}`);
        await persistAndSync({ extraction: parsed, sourceKind: "text", sourceName: "pasted-grid.txt" });
      });
    },
    [mark, month, persistAndSync, profile, runPipeline, year]
  );

  const cropAndReparse = useCallback(
    async (dataUrl: string) => {
      await runPipeline(async () => {
        mark("ingest", "done", "Cropped staff row");
        mark("preprocess", "done", "Row isolator crop");
        mark("identity", "running");
        const res = await fetch("/api/ocr/parse", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            filename: "cropped-row.png",
            mime: "image/png",
            dataUrl,
            profile,
            month,
            year,
          }),
        });
        const json = await res.json();
        mark("identity", "done", "Re-locked from bounding box");
        await persistAndSync({
          extraction: json.result,
          sourceKind: "image",
          sourceName: "cropped-row.png",
          dataUrl,
        });
      });
    },
    [mark, month, persistAndSync, profile, runPipeline, year]
  );

  const updateCell = useCallback(
    async (day: number, code: string) => {
      if (!document) return;
      const def = lookupShift(code, customShifts) ?? shiftByType("CUSTOM");
      const schedule = document.extraction.schedule.map((cell) =>
        cell.day === day
          ? {
              ...cell,
              raw_code: code,
              normalized_type: def.normalizedType,
              is_split_shift: def.normalizedType === "SPLIT",
              split_segments: def.splitSegments,
              start: def.start,
              end: def.end,
              confidence: 1,
              is_ambiguous: false,
              patched: true,
              previous_code: cell.raw_code,
            }
          : cell
      );
      const extraction = { ...document.extraction, schedule };
      const sequence = document.sequence + 1;
      const next: RotaDocument = {
        ...document,
        extraction,
        sequence,
        updatedAt: new Date().toISOString(),
        sourceKind: document.sourceKind === "demo" ? "manual" : document.sourceKind,
      };
      setDocument(next);
      setLastDiff((n) => n + 1);
      await saveRota(next);
      try {
        await fetch(`/api/webcal/${webcalToken}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ extraction, profile, sequence, privacy }),
        });
      } catch {
        /* offline — feed will catch up */
      }
    },
    [customShifts, document, privacy, profile, webcalToken]
  );

  const downloadIcs = useCallback(() => {
    if (!extraction) return;
    const ics = generateIcs({
      extraction,
      profile,
      sequence: document?.sequence ?? 1,
      privacy,
    });
    downloadBlob(icsFilename(extraction), ics, "text/calendar;charset=utf-8");
  }, [document?.sequence, extraction, privacy, profile]);

  const value: RotaContextValue = {
    ready,
    profile,
    privacy,
    customShifts,
    engine,
    webcalToken,
    document,
    extraction,
    sourceUrl,
    pipeline,
    processing,
    issues,
    analytics,
    lastDiff,
    month,
    year,
    setEngine,
    setMonthYear,
    updateProfile,
    updatePrivacy,
    saveCustomShift,
    ingestFiles,
    ingestDemo,
    ingestText,
    updateCell,
    downloadIcs,
    webcalHttpUrl,
    webcalUrl,
    cropAndReparse,
  };

  return <RotaContext.Provider value={value}>{children}</RotaContext.Provider>;
}
